	 $.ajaxSetup({
		 cache:false,
	 });
	
	function test(){
		datagraid_load();
		//$("#btn-todo").attr("disabled", true);
		zeroModal.show({
	        title: '正在预测请稍候...',
	        width:'20%',
	        height:'40%',
	        transition: true,
	        close: false,
	    });
		$("#btn-todo").onclick = add();
		function add(){
				var url="/MVC_1/youhua.do";
				var date1 = $('#date-picker-input-1').val();
				var datee = moment(date1).format("YYYY-MM-DD");
				var today = moment().format("YYYY-MM-DD");
				
//				if(datee > today){
//					zeroModal.closeAll();
//					return;
//				}
				
				var args ={"time":new Date().getTime(), "date": datee};
				$.getJSON(url,args,function(csv){
					//$("#btn-todo").attr("disabled", false);
					zeroModal.closeAll();
					
					if(csv == null){
						alert("预测失败");
						return;
					}
					
					 $("#container").highcharts({
					        chart: {
					            type: 'line',
					            backgroundColor: '#C6E2FF',
					        },
					        colors:["#FF3300"],
					        credits:{
					        	text:'',
					        	href:'',
					        },
					        title: {
					            text: '电池储能',
					            style: {
					            	color:"black",
					            } 
					        },
					        credits: {
					        	text: " ",
					        	href: " "
					        },
					        legend:{
					        	align: 'right',
					        	layout: 'vertical',
					        	x: 0,
					        	verticalAlign: 'top',
					        	y: 100,
					        	enable: true,
					        	itemHoverStyle: false,
					        	itemStyle: {
					        		color: '',
					        	}
					        },
					        subtitle: {
//					        	text: '本次预测准确率: ' + csv[2] + "%",
//					        	style: {
//					        		color: "black",
//					        		fontSize: '16px',
//					        	}
					        },
					        exporting:{
					        	enabled:false
					        },
					        xAxis: {
					        	categories: ["0:00","0:15","0:30","0:45","1:00","1:15","1:30","1:45","2:00","2:15","2:30","2:45","3:00","3:15","3:30","3:45","4:00","4:15","4:30","4:45","5:00","5:15","5:30","5:45","6:00","6:15","6:30","6:45","7:00","7:15","7:30","7:45","8:00","8:15","8:30","8:45","9:00","9:15","9:30","9:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45","12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45","16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45","20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"],	
					        },
					        yAxis: {
					            title: {
					                text: 'y'
					            }
					        },
					        plotOptions: {
					            line: {
					                dataLabels: {
					                    enabled: false
					                },
					                enableMouseTracking: true
					            },
					            
					            series: {
					            	
					                point: {
					                    events: {

					                        drag: function (e) {
					                        	
					                        },
					                        drop: function (e) {
					                        	
					                        	zeroModal.confirm({
					                                content: "确认更改 id = "+ (parseInt(e.x)+1) +" 的值为:",
					                                contentDetail: "<input id='insert1' type='text' style='color:red' value="+ e.y +">",
					                                okFn: function() {
					                                	$.get("/MVC_1/insertOne.do?datet="+ $("#date-picker-input-1").val() +"&id="+ (parseInt(e.x)+1) +"&y="+ $("#insert1").val(),{"time":new Date().getTime()},function(data){
					                            		});
					                                	test();
					                                },
					                                cancelFn: function() {
					                                    alert('cancel');
					                                }
					                            });
					                        	
					                        }
					                    }
					                },
					                stickyTracking: false
					            },
					        },
					        series: [{
					            name: '电池储能',
					            data: csv[4],
					            draggableY: true,
					            dragMinY: 0,
					            marker:{enabled:false,},
				            	}]
					    });
				});
		}
	}

	$("#Charu").click(function(){
		$.get("/MVC_1/add.do?",{"time":new Date().getTime()},function(data){
		}); 
	});
	
	$("#delete").click(function(){
		$.get("/MVC_1/delete.do?",{"time":new Date().getTime()},function(data){
		}); 
	});
	
//	$(function(){
//		$("#Yuce").on("click",function(){
//			alert($("#date-picker-input-1").val());
//		});
//		
//	});
	
	$(function() {
		$("#date-picker-input-1").datepicker({
			inline: true,
			showOtherMonths: true,
			altFormat: "yyyy-mm-dd"
		}).datepicker('widget').wrap('<div class="ll-skin-latoja"/>');
		 $("#date-picker-input-1").datepicker( "option", "dateFormat",  "yy-mm-dd");
		 $("#date-picker-input-1").datepicker( 'setDate' , "2017-03-12");
	});
	
	$(":radio").click(
		    function(){
		     var nm=$(this).attr("name");
		     $(":radio[name="+nm+"]:not(:checked)").attr("tag",0);
		     if($(this).attr("tag")==1){$(this).attr("checked",false);$(this).attr("tag",0); }
		     else{$(this).attr("tag",1);}                 
		             }
		       )

function setRowBgColor(index, row) {
	            return 'background-color:#8DB4E2;';
		    }

	 function datagraid_load() {
			$('#datagrid').datagrid({
	    url: '/MVC_1/shuju.do',
	    method: 'get',
	    striped: true,
	    fitColumns: true,
	    singleSelect: true,
	    rownumbers: false,
	    pagination: false,
	    nowrap: false,
	    pageSize: 4,
	    rowStyler: setRowBgColor,
	    pageList: [4, 8, 12, 16, 20, 24],
	    showFooter: true,
	    columns: [[
	        { field: 'cITY_ID', title: 'CITY_ID', align: 'left' },
	        { field: 'dATA_DATE', title: 'DATA_DATE', align: 'left' },
	        { field: 'gROUP_ID', title: 'GROUP_ID', align: 'left' },
	        { field: 'eC_DATA_TYPE', title: 'EC_DATA_TYPE', align: 'left' },
	        { field: 'eC_DATA_POINT', title: 'EC_DATA_POINT', align: 'left' },
	        { field: 'eC_ENERGY_1', title: 'EC_ENERGY_1', align: 'left' },
	        { field: 'eC_ENERGY_2', title: 'EC_ENERGY_2', align: 'left' },
	        { field: 'eC_ENERGY_3', title: 'EC_ENERGY_3', align: 'left' },
	        { field: 'eC_ENERGY_4', title: 'EC_ENERGY_4', align: 'left'},
	        { field: 'eC_ENERGY_5', title: 'EC_ENERGY_5', align: 'left'},
	        { field: 'eC_ENERGY_6', title: 'EC_ENERGY_6', align: 'left'},
	        { field: 'eC_ENERGY_7', title: 'EC_ENERGY_7', align: 'left'},
	        { field: 'eC_ENERGY_8', title: 'EC_ENERGY_8', align: 'left'},
	        { field: 'eC_ENERGY_9', title: 'EC_ENERGY_9', align: 'left'},
	        { field: 'eC_ENERGY_10', title: 'EC_ENERGY_10', align: 'left'},
	        { field: 'eC_ENERGY_11', title: 'EC_ENERGY_11', align: 'left'},
	        { field: 'eC_ENERGY_12', title: 'EC_ENERGY_12', align: 'left'},
	        { field: 'eC_ENERGY_13', title: 'EC_ENERGY_13', align: 'left',
	            editor: {
	                type: 'numberbox',
	                options: {
	                    min: 0,
	                    precision: 0
	                }
	            }
	        }
	    ]],
	    onBeforeLoad: function (param) {
	    },
	    onLoadSuccess: function (data) {
	        
	    },
	    onLoadError: function () {
	        
	    },
	    onClickCell: function (rowIndex, field, value) {
	        
	    }
	});
}
