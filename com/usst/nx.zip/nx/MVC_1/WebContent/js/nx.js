
$(window).resize(function() {
		        var h = $('.nx-img').height()+'px';
				$('.img').css("height", h);
				});

//window.onresize(function(){
//	 var h = $('.nx-img').height()+'px';
//				$('.img').css("height", h);
//			});