var setting = {
    		check: {
				enable: true,
				chkboxType: { "Y": "", "N": "" },
			},
            async : {  
                enable : true,//开启异步加载处理  
                url : "/MVC_1/shu.do",  
                autoParam : ["id"],  
                dataFilter : filter,  
                contentType : "application/json",  
                type : "get"  
            },  
            view : { 
            	showIcon: false,
                expandSpeed : "",  
                
                selectedMulti : true
            },  
            edit : {  
                enable : false  
            },  
            data : {  
                simpleData : {  
                    enable : true  
                }  
            },  
            callback : {  

            }  
        };  
        function filter(treeId, parentNode, childNodes) {  
            if (!childNodes)  
                return null;  
            for (var i = 0, l = childNodes.length; i < l; i++) {  
                childNodes[i].name = childNodes[i].name.replace(/\.n/g, '.');  
            }  
            return childNodes;  
        }  

        $(document).ready(function() {  
            $.fn.zTree.init($("#treeDemo"), setting);
        }); 
        
function test4(){
    var treeObj = $.fn.zTree.getZTreeObj("treeDemo");
    var nodes = treeObj.getCheckedNodes(true);
    for(i = 0; i < nodes.length; i++) {
         alert(nodes[i].id + " " + nodes[i].pId);
   }
}