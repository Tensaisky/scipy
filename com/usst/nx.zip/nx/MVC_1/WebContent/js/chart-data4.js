function test2(){
	zeroModal.show({
        title: '正在优化请稍候...',
        width:'15%',
        height:'20%',
        transition: true,
        close: false,
    });
		$("#btn-todo").onclick = add();
		function add(){
				var url="/MVC_1/youhua.do";
				var datee = $('#date-picker-input-1').val();
				var args ={"time":new Date().getTime(), "date": datee};
				$.getJSON(url,args,function(csv){
					zeroModal.closeAll();
					if(csv == null){
						alert("优化失败");
						return;
					}
					 $("#container3").highcharts({
					        chart: {
					            type: 'line',
					            backgroundColor: '#C6E2FF',
					        },
					        
					        colors:["#000000","#2E8B57","#5571DD","#FF9933","#C8049E","#FF3300"],
					        credits:{
					        	text:'',
					        	href:''
					        },
					        title: {
					            text: '智能用电规划',
					            style: {
					            	color:"black",
					            }
					        },
					        legend: {  
					            align: 'right',
					            layout: 'vertical',
					            x: 0,  
					            verticalAlign: 'top',  
					            y: 100,
					            enabled:true,
					            itemHoverStyle: false,
					            itemStyle : {
					                color: '',
					            }
					        },
					        credits: {
					        	text: " ",
					        	href: " "
					        },
					        subtitle: {
					            text: ''
					        },
					        exporting:{
					        	enabled:false
					        },
					        xAxis: {
					        	categories: ["0:00","0:15","0:30","0:45","1:00","1:15","1:30","1:45","2:00","2:15","2:30","2:45","3:00","3:15","3:30","3:45","4:00","4:15","4:30","4:45","5:00","5:15","5:30","5:45","6:00","6:15","6:30","6:45","7:00","7:15","7:30","7:45","8:00","8:15","8:30","8:45","9:00","9:15","9:30","9:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45","12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45","16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45","20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"],	
					        },
					        yAxis: {
					            title: {
					                text: '电量（kWh）'
					            },
					            gridLineColor: '#5F9EA0',//横向网格线颜色
					            gridLineDashStyle: 'solid',//横向网格线样式
					            gridLineWidth: 0.5,//横向网格线宽度
					        },
					        plotOptions: {
					            line: {
					            	lineWidth: 2,
					                dataLabels: {
					                    enabled: false
					                },
					                enableMouseTracking: true,
					                showLegend: true
					            },
					            
					            series: {
					            	
					            	events:{
					            		legendItemClick: function() {
					                        return false;
					                    }
					            	},
					            	
					            	marker: {
			                            radius: 2,
					            	},
					                point: {
					                    events: {

					                        drag: function (e) {
					                        	
					                        },
					                        drop: function (e) {
					                        	
					                        }
					                    }
					                },
					                stickyTracking: false
					            },
					        },
					        series: [
					        	{
					        		 name: '居民用电负荷',
							         data: csv[1],
					            },
					            {
					            	 name: '风力发电量',
							         data: csv[2],
					            },
					            {
					            	 name: '太阳能',
							         data: csv[3],
					            },
					            {
					            	 name: '燃气发电量',
							         data: csv[4],
					            },
					            {
					            	 name: '电池供电',
							         data: csv[5],

					            },
					            {
					            	 name: '电网供电',
							         data: csv[7],
					            }
					            ]
					    });
				});
		}
	}

function test3(){
	zeroModal.show({
        title: '正在预测请稍候...',
        width:'15%',
        height:'20%',
        transition: true,
        close: false,
    });
	$("#date-picker-input-1").onchange = add();
	function add(){
			var url="/MVC_1/youhua.do";
			var datee = $('#date-picker-input-1').val();
			var args ={"time":new Date().getTime(), "date": datee};
			$.getJSON(url,args,function(csv){
				zeroModal.closeAll();
				 $("#container").highcharts({
				        chart: {
				            type: 'line',
				            backgroundColor: '#C6E2FF',
				        },
				        colors:["#000000","#2E8B57","#5571DD","#FF9933"],
				        credits:{
				        	text:'',
				        	href:''
				        },
				        title: {
				            text: '负荷预测/发电量预测',
				            style: {
				            	color:"black",
				            }
				        },
				        legend: {  
				            align: 'right',
				            layout: 'vertical',
				            x: 0,  
				            verticalAlign: 'top',  
				            y: 100,
				            enabled:true,
				            itemHoverStyle: false,
				            itemStyle : {
				                color: '',
				            }
				        },
				        credits: {
				        	text: " ",
				        	href: " "
				        },
				        subtitle: {
				            text: ''
				        },
				        exporting:{
				        	enabled:false
				        },
				        xAxis: {
				        	categories: ["0:00","0:15","0:30","0:45","1:00","1:15","1:30","1:45","2:00","2:15","2:30","2:45","3:00","3:15","3:30","3:45","4:00","4:15","4:30","4:45","5:00","5:15","5:30","5:45","6:00","6:15","6:30","6:45","7:00","7:15","7:30","7:45","8:00","8:15","8:30","8:45","9:00","9:15","9:30","9:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45","12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45","16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45","20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"]
				        },
				        yAxis: {
				            title: {
				                text: '电量（kWh）'
				            },
				            // tickInterval: 1,
				            gridLineColor: '#5F9EA0',//横向网格线颜色
				            gridLineDashStyle: 'solid',//横向网格线样式
				            gridLineWidth: 0.5,//横向网格线宽度
				        },
				        plotOptions: {
				            line: {
				            	lineWidth: 2,
				                dataLabels: {
				                    enabled: false
				                },
				                enableMouseTracking: true,
				                showLegend: true
				            },
				            
				            series: {
				            	events:{
				            		legendItemClick: function() {
				                        return false;
				                    }
				            	},
				            	marker: {
		                            radius: 2,
				            	},
				                point: {
				                    events: {

				                        drag: function (e) {
				                        	
				                        },
				                        drop: function (e) {
				                        	
				                        }
				                    }
				                },
				                stickyTracking: false
				            },
				        },
				        series: [
				        	{
				                name: '居民用电负荷',
				                data: csv[1],
				            },
				            {
				                name: '风力发电',
				                data: csv[2],
				            },
				            {
				                name: '太阳能发电',
				                data: csv[3],
				            },
				            {
				                name: '燃气发电',
				                data: csv[4],
				            }
				            ]
				    });
			});
	}
}

function eleconfig(){
//	$('#container').empty();
//	$("#containerin").css('display','block');
}
