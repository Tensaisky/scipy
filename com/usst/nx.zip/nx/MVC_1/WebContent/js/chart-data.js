	 $.ajaxSetup({
		 cache:false,
	 });

//	$(document).ready(function() {  
//	    $.fn.zTree.init($("#treeDemo"), setting);
//	}); 
	 
 function datagraid_load() {
			$('#datagrid').datagrid({
			    url: '/MVC_1/shuju.do',
			    method: 'get',
			    striped: true,
			    fitColumns: true,
			    singleSelect: true,
			    rownumbers: false,
			    pagination: false,
			    nowrap: false,
			    pageSize: 4,
			    rowStyler: setRowBgColor,
			    pageList: [4, 8, 12, 16, 20, 24],
			    showFooter: true,
			    columns: [[
			        { field: 'cITY_ID', title: 'CITY_ID', align: 'left' },
			        { field: 'dATA_DATE', title: 'DATA_DATE', align: 'left' },
			        { field: 'gROUP_ID', title: 'GROUP_ID', align: 'left' },
			        { field: 'eC_DATA_TYPE', title: 'EC_DATA_TYPE', align: 'left' },
			        { field: 'eC_DATA_POINT', title: 'EC_DATA_POINT', align: 'left' },
			        { field: 'eC_ENERGY_1', title: 'EC_ENERGY_1', align: 'left' },
			        { field: 'eC_ENERGY_2', title: 'EC_ENERGY_2', align: 'left' },
			        { field: 'eC_ENERGY_3', title: 'EC_ENERGY_3', align: 'left' },
			        { field: 'eC_ENERGY_4', title: 'EC_ENERGY_4', align: 'left'},
			        { field: 'eC_ENERGY_5', title: 'EC_ENERGY_5', align: 'left'},
			        { field: 'eC_ENERGY_6', title: 'EC_ENERGY_6', align: 'left'},
			        { field: 'eC_ENERGY_7', title: 'EC_ENERGY_7', align: 'left'},
			        { field: 'eC_ENERGY_8', title: 'EC_ENERGY_8', align: 'left'},
			        { field: 'eC_ENERGY_9', title: 'EC_ENERGY_9', align: 'left'},
			        { field: 'eC_ENERGY_10', title: 'EC_ENERGY_10', align: 'left'},
			        { field: 'eC_ENERGY_11', title: 'EC_ENERGY_11', align: 'left'},
			        { field: 'eC_ENERGY_12', title: 'EC_ENERGY_12', align: 'left'},
			        { field: 'eC_ENERGY_13', title: 'EC_ENERGY_13', align: 'left',
			            editor: {
			                type: 'numberbox',
			                options: {
			                    min: 0,
			                    precision: 0
			                }
			            }
			        }
			    ]],
			    onBeforeLoad: function (param) {
			    },
			    onLoadSuccess: function (data) {
			        
			    },
			    onLoadError: function () {
			        
			    },
			    onClickCell: function (rowIndex, field, value) {
			        
			    }
			});
 }
	 
	function test1(){
		
		datagraid_load();
		zeroModal.show({
	        title: '正在评级请稍候...',
	        width:'20%',
	        height:'40%',
	        transition: true,
	        close: false,
	    });
		$("#btn-todo").onclick = add();
		function add(){
				 var id_array=new Array();
				 var treeObj = $.fn.zTree.getZTreeObj("treeDemo");
				 var nodes = treeObj.getCheckedNodes(true);
				 for(i = 0; i < nodes.length; i++) {
					 if(nodes[i].IsValid == 0){
						 zeroModal.closeAll();
						 alert("输入点无效，请重新输入");
						 return;
					 }
				     id_array.push(nodes[i].id);//向数组中添加元素  
				 }  
				 var idstr=id_array.join(',');//将数组元素连接起来以构建一个字符串  
				 //alert(idstr); 
				 
				 
				var nodes = test4();
			    var nodes_name = new Array();
			    for(i = 0; i < nodes.length; i++) {
			    	nodes_name[i] = nodes[i].name.substring(0,7);
			   }
				 
				var url="/MVC_1/zhiFangtu.do";
				var datee = $('#date-picker-input-1').val();
				var datef = moment(datee).format("YYYY-MM-DD");
				var now = moment().format("YYYY-MM-DD");
				
//				var day1 = new Date();
//				day1.setTime(day1.getTime()-24*60*60*1000);
//				var s1 = day1.getFullYear()+"-" + (day1.getMonth()+1) + "-" + day1.getDate();
//				alert(s1);
				
				if(datef >= now){
					return;
				}
				
				var args ={"time":new Date().getTime(), "datez": datee, "group_ids": idstr};
				$.getJSON(url,args,function(csv){
					
					//$("#btn-todo").attr("disabled", false);
					zeroModal.closeAll();
					
					var finalData = [];

					for(var i=0;i<csv.length;i++) {
					  var d = csv[i];
					  finalData.push({
					    y: d,
					    color: d > 6 ? 'green' : 'red'   // 根据值判断给定颜色
					  })
					} 
					
					var colorArr = ['#7cb5ec', '#434348', '#90ed7d', '#f7a35c', '#8085e9','#f15c80', '#e4d354', '#8085e8', '#8d4653', '#91e8e1','#000000','#560f23'];
					
					 $("#container").highcharts({
					        chart: {
					            type: 'column',
//					            backgroundColor: {
//					                linearGradient: [0, 0, 500, 500],
//					                stops: [
//					                    [0, 'rgb(255, 255, 255)'],
//					                    [1, 'rgb(200, 200, 255)']
//					                ]
//					            },
					            backgroundColor: '#C6E2FF',
					        },

					        title: {
					            text: '电能质量评估',
					            style: {
					            	color:"black",
					            }
					        },
					        subtitle: {
					            text: ''
					        },
					        credits: {
					        	text: " ",
					        	href: " "
					        },
					        legend:{
					        	enabled:false
					        },
					        exporting:{
					        	enabled:false
					        },
					        xAxis: {
//					        	labels: {
//					        	    formatter:function(){
//					        	     return nodes_name
//					        	    }
//					        	  }
					        	categories: nodes_name,
					        },
					        yAxis: {
					            title: {
					                text: '能效等级（1-10）'
					            },
					            // tickInterval: 1,
					            gridLineColor: '#5F9EA0',//横向网格线颜色
					            gridLineDashStyle: 'solid',//横向网格线样式
					            gridLineWidth: 0.5,//横向网格线宽度
					        },
					        plotOptions: {
					            line: {
					                dataLabels: {
					                    enabled: false
					                },
					                enableMouseTracking: true
					            },
					            
					            series: {
					            	
					                point: {
					                    events: {

					                        drag: function (e) {
					                        	
					                        },
					                        drop: function (e) {
					                        	
//					                        	zeroModal.confirm({
//					                                content: "确认更改 id = "+ (parseInt(e.x)+1) +" 的值为:",
//					                                contentDetail: "<input id='insert1' type='text' style='color:red' value="+ e.y +">",
//					                                okFn: function() {
//					                                	$.get("/MVC_1/insertOne.do?datet="+ $("#date-picker-input-1").val() +"&id="+ (parseInt(e.x)+1) +"&y="+ $("#insert1").val(),{"time":new Date().getTime()},function(data){
//					                            		});
//					                                	test();
//					                                },
//					                                cancelFn: function() {
//					                                    alert('cancel');
//					                                }
//					                            });
					                        	
					                        }
					                    }
					                },
					                stickyTracking: false
					            },
					        },
					        series: [{
					            name: '用电',
					            data: finalData,
					            color: '#66EE81',
					            pointWidth: 80,
					            draggableY: false,
					            dragMinY: 0,
					            marker:{
				            		enabled:false,
				            	},
					        }]
					    });
//					 for(var i = 0; i < csv.length; i++){
//						 if(csv[1] == "-301"){
//							 alert("无效数据（-301）");
//						 }
//					 }
					 
				});

		}
	}

	$("#Charu").click(function(){
		$.get("/MVC_1/add.do?",{"time":new Date().getTime()},function(data){
		}); 
	});
	
	$("#delete").click(function(){
		$.get("/MVC_1/delete.do?",{"time":new Date().getTime()},function(data){
		}); 
	});

	$(function() {
	        $("#datetimepicker2").datetimepicker({
	        	format: 'yyyy-mm-dd hh:ii',
	            autoclose: true,
	            todayBtn: true,
	        });
			 
//		$( "#date-picker-input-1" ).datepicker({
//			inline: true,
//			showOtherMonths: true,
//			altFormat: "yyyy-mm-dd"
//		})
//		.datepicker('widget').wrap('<div class="ll-skin-latoja"/>');
//		 $( "#date-picker-input-1" ).datepicker( "option", "dateFormat",  "yy-mm-dd");
//		 $( "#date-picker-input-1" ).datepicker( 'setDate' , "2017-03-12");
	});
	
//	$(function(){
//		$("#Yuce").on("click",function(){
//			alert($("#date-picker-input-1").val());
//		});
//		
//	});
	
	$(":radio").click(
		    function(){
		     var nm=$(this).attr("name");
		     $(":radio[name="+nm+"]:not(:checked)").attr("tag",0);
		     if($(this).attr("tag")==1){$(this).attr("checked",false);$(this).attr("tag",0); }
		     else{$(this).attr("tag",1);}                 
		             }
		       )

function setRowBgColor(index, row) {
	            return 'background-color:#8DB4E2;';
		    }		       

//	$(function () {
//        var fanxiBox = $("#sidetree input:checkbox");
//        fanxiBox.click(function () {
//           if(this.checked || this.checked=='checked'){
//               fanxiBox.removeAttr("checked");
//               $(this).prop("checked", true);
//             }
//        });
//     }); 
