	 $.ajaxSetup({
		 cache:false,
	 });
	
	function test(){
		datagraid_load();
		//$("#btn-todo").attr("disabled", true);
		zeroModal.show({
	        title: '正在预测请稍候...',
	        width:'20%',
	        height:'40%',
	        transition: true,
	        close: false,
	    });
		$("#btn-todo").onclick = add();
		function add(){
				var url="/MVC_1/query.do";
				var date1 = $('#date-picker-input-1').val();
				var datee = moment(date1).format("YYYY-MM-DD");
				var today = moment().format("YYYY-MM-DD");
				
//				if(datee > today){
//					zeroModal.closeAll();
//					return;
//				}
				
				var args ={"time":new Date().getTime(), "date": datee};
				$.getJSON(url,args,function(csv){
					//$("#btn-todo").attr("disabled", false);
					zeroModal.closeAll();
					
					if(csv == null){
						alert("预测失败");
						return;
					}
					
					 $("#container").highcharts({
					        chart: {
					            type: 'line',
//					            backgroundColor: '#C6E2FF',
					        },
					        colors:["#218868","#FF3300"],
					        credits:{
					        	text:'',
					        	href:'',
					        },
					        title: {
					            text: '短期负荷预测',
					            style: {
					            	color:"black",
					            } 
					        },
					        credits: {
					        	text: " ",
					        	href: " "
					        },
					        legend:{
					        	align: 'right',
					        	layout: 'vertical',
					        	x: 0,
					        	verticalAlign: 'top',
					        	y: 100,
					        	enable: true,
					        	itemHoverStyle: false,
					        	itemStyle: {
					        		color: '',
					        	}
					        },
					        subtitle: {
					        	text: '准确率: ' + csv[2] + "%",
					        	style: {
					        		color: "black",
					        		fontSize: '16px',
					        	}
					        },
					        exporting:{
					        	enabled:false
					        },
					        xAxis: {
					        	categories: ["0:00","1:00","2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
					        },
					        yAxis: {
					        	min: 0,
					        	max: 20000,
					            title: {
					                text: '功率（kW）'
					            },
					            // tickInterval: 1,
					            gridLineColor: '#5F9EA0',//横向网格线颜色
					            gridLineDashStyle: 'solid',//横向网格线样式
					            gridLineWidth: 0.5,//横向网格线宽度
					        },
					        plotOptions: {
					            line: {
					                dataLabels: {
					                    enabled: false
					                },
					                enableMouseTracking: true
					            },
					            
					            series: {
					            	
					                point: {
					                    events: {

					                        drag: function (e) {
					                        	
					                        },
					                        drop: function (e) {
					                        	
					                        	zeroModal.confirm({
					                                content: "确认更改 id = "+ (parseInt(e.x)+1) +" 的值为:",
					                                contentDetail: "<input id='insert1' type='text' style='color:red' value="+ e.y +">",
					                                okFn: function() {
					                                	$.get("/MVC_1/insertOne.do?datet="+ $("#date-picker-input-1").val() +"&id="+ (parseInt(e.x)+1) +"&y="+ $("#insert1").val(),{"time":new Date().getTime()},function(data){
					                            		});
					                                	test();
					                                },
					                                cancelFn: function() {
					                                    alert('cancel');
					                                }
					                            });
					                        	
					                        }
					                    }
					                },
					                stickyTracking: false
					            },
					        },
					        series: [{
					            name: '预测值',
					            data: csv[0],
					            draggableY: true,
					            dragMinY: 0,
					            marker:{enabled:false,},
				            	},{
						            name: '实际值',
						            data: csv[1],
						            draggableY: true,
						            dragMinY: 0,
						            marker:{enabled:false,},
						            }, ]
					    });
				});
		}
	}

	$("#Charu").click(function(){
		$.get("/MVC_1/add.do?",{"time":new Date().getTime()},function(data){
		}); 
	});
	
	$("#delete").click(function(){
		$.get("/MVC_1/delete.do?",{"time":new Date().getTime()},function(data){
		}); 
	});
	
//	$(function(){
//		$("#Yuce").on("click",function(){
//			alert($("#date-picker-input-1").val());
//		});
//		
//	});
	
	$(function() {
		$("#date-picker-input-1").datepicker({
			inline: true,
			showOtherMonths: true,
			altFormat: "yyyy-mm-dd",
		     maxDate: "-1D",
		}).datepicker('widget').wrap('<div class="ll-skin-latoja"/>');
		 $("#date-picker-input-1").datepicker( "option", "dateFormat",  "yy-mm-dd");
		 $("#date-picker-input-1").datepicker( 'setDate' , "2017-03-12");
	});
	
	$(":radio").click(
		    function(){
		     var nm=$(this).attr("name");
		     $(":radio[name="+nm+"]:not(:checked)").attr("tag",0);
		     if($(this).attr("tag")==1){$(this).attr("checked",false);$(this).attr("tag",0); }
		     else{$(this).attr("tag",1);}                 
		             }
		       )

function setRowBgColor(index, row) {
	            return 'background-color:#8DB4E2;';
		    }

	 function datagraid_load() {
			$('#datagrid').datagrid({
	    url: '/MVC_1/shuju.do',
	    method: 'get',
	    striped: true,
	    fitColumns: true,
	    singleSelect: true,
	    rownumbers: false,
	    pagination: false,
	    nowrap: false,
	    pageSize: 4,
	    rowStyler: setRowBgColor,
	    pageList: [4, 8, 12, 16, 20, 24],
	    showFooter: true,
	    columns: [[
	        { field: 'average', title: 'AVERAGE', align: 'left' },
	        { field: 'eC_ENERGY_1', title: 'EC_ENERGY_1', align: 'left' },
	        { field: 'eC_ENERGY_2', title: 'EC_ENERGY_2', align: 'left' },
	        { field: 'eC_ENERGY_3', title: 'EC_ENERGY_3', align: 'left' },
	        { field: 'eC_ENERGY_4', title: 'EC_ENERGY_4', align: 'left'},
	        { field: 'eC_ENERGY_5', title: 'EC_ENERGY_5', align: 'left'},
	        { field: 'eC_ENERGY_6', title: 'EC_ENERGY_6', align: 'left'},
	        { field: 'eC_ENERGY_7', title: 'EC_ENERGY_7', align: 'left'},
	        { field: 'eC_ENERGY_8', title: 'EC_ENERGY_8', align: 'left'},
	        { field: 'eC_ENERGY_9', title: 'EC_ENERGY_9', align: 'left'},
	        { field: 'eC_ENERGY_10', title: 'EC_ENERGY_10', align: 'left'},
	        { field: 'eC_ENERGY_11', title: 'EC_ENERGY_11', align: 'left'},
	        { field: 'eC_ENERGY_12', title: 'EC_ENERGY_12', align: 'left'},
	        { field: 'eC_ENERGY_13', title: 'EC_ENERGY_13', align: 'left'},
	        { field: 'eC_ENERGY_6', title: 'EC_ENERGY_14', align: 'left'},
	        { field: 'eC_ENERGY_7', title: 'EC_ENERGY_15', align: 'left'},
	        { field: 'eC_ENERGY_8', title: 'EC_ENERGY_16', align: 'left'},
	        { field: 'eC_ENERGY_9', title: 'EC_ENERGY_17', align: 'left'},
	        { field: 'eC_ENERGY_10', title: 'EC_ENERGY_18', align: 'left'},
	        { field: 'eC_ENERGY_11', title: 'EC_ENERGY_19', align: 'left'},
	        { field: 'eC_ENERGY_12', title: 'EC_ENERGY_20', align: 'left'},
	        { field: 'eC_ENERGY_13', title: 'EC_ENERGY_21', align: 'left'},
	        { field: 'eC_ENERGY_11', title: 'EC_ENERGY_22', align: 'left'},
	        { field: 'eC_ENERGY_12', title: 'EC_ENERGY_23', align: 'left'},
	        { field: 'eC_ENERGY_13', title: 'EC_ENERGY_24', align: 'left'},
	    ]],
	    onBeforeLoad: function (param) {
	    },
	    onLoadSuccess: function (data) {
	        
	    },
	    onLoadError: function () {
	        
	    },
	    onClickCell: function (rowIndex, field, value) {
	        
	    }
	});
}
//	$(function () {
//        var fanxiBox = $("#sidetree input:checkbox");
//        fanxiBox.click(function () {
//           if(this.checked || this.checked=='checked'){
//               fanxiBox.removeAttr("checked");
//               $(this).prop("checked", true);
//             }
//        });
//     }); 
