package com.usst.ee;
import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Properties;

import javax.sql.rowset.JdbcRowSet;



public class DEMO
{
	private String oracle_driver;
	private String oracle_url;
	private String oracle_user;
	private String oracle_pass;
	
	private void test1()
	{
		EE a = EE.getEE(123);
		System.out.println(a.testoutput());
		System.out.println(a.testoutput1());
	}
	
	private void test2()
	{
		EE a = EE.getEE(123);
		System.out.println(a.testoutput());
		System.out.println(a.testoutput1());
	}
	
	public void initParam()throws Exception
	{
		Properties props = new Properties();
		props.load(new FileInputStream("C:/Users/WORK01/Desktop/nx/MVC_1/src/oracle.ini"));
		oracle_driver = props.getProperty("driver");
		oracle_url = props.getProperty("url");
		oracle_user = props.getProperty("user");
		oracle_pass = props.getProperty("pass");	
	}
	
	{
		try {
			initParam();
			Class.forName(oracle_driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public double[] getInput(int group_id, Date inputDate) throws Exception
	{

		Connection oracle_conn = null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;

		double[] inputData = new double[10];
		java.sql.Date date2 = new java.sql.Date(inputDate.getTime());
		System.out.println(date2);
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(inputDate);
		int hours = calendar.get(Calendar.HOUR);
		int minutes = calendar.get(Calendar.MINUTE);
		int count = (int) (hours * 12 + Math.ceil(minutes/5.0) + 1);
		String[] ec12 = new String[]{"EC_QUALITY_" + count,"EC_QUALITY_" + count,
						"EC_FACTOR_" + count, "EC_QUALITY_" + count, 
						"EC_HAR_CUR_DIST_" + count, "EC_HAR_CUR_DIST_" + count,
						"EC_HAR_CUR_DIST_" + count,"EC_HAR_VOL_DIST_" + count,
						"EC_HAR_VOL_DIST_" + count, "EC_HAR_VOL_DIST_" + count};
		String[] curve = new String[]{"NXGL.EC_D_QUALITY_CURVE","NXGL.EC_D_QUALITY_CURVE",
					"NXGL.EC_D_FACTOR_CURVE","NXGL.EC_D_QUALITY_CURVE",
					"NXGL.EC_D_HARMONIC_CUR_DIST_CURVE","NXGL.EC_D_HARMONIC_CUR_DIST_CURVE",
					"NXGL.EC_D_HARMONIC_CUR_DIST_CURVE","NXGL.EC_D_HARMONIC_VOL_DIST_CURVE",
					"NXGL.EC_D_HARMONIC_VOL_DIST_CURVE","NXGL.EC_D_HARMONIC_VOL_DIST_CURVE"};
		int[] ecDataType = new int[]{7, 14, 40, 42, 103, 104, 105, 303, 304, 305};

		try{
			//System.out.println("oracle1");
			oracle_conn = DriverManager.getConnection(oracle_url, oracle_user, oracle_pass);
			//System.out.println("oracle2");
			String sql =null;
			for(int i=0; i<10; i++){
				sql = getSql(ec12[i], curve[i], group_id, ecDataType[i], date2);
				preparedStatement=oracle_conn.prepareStatement(sql);
				//System.out.println("sql prepared");
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next()){
					inputData[i] = resultSet.getDouble(1);
				}
			}
		}catch (Exception e) {
			inputData = null;
			//e.printStackTrace();
		}
		//System.out.println(inputData.length);
//		for(int i=0; i<10; i++)
//			System.out.print(inputData[i] + " ");
		return inputData;
	}
	
	public String getSql(String ec12, String curve, int groupId, int ecDataType, java.sql.Date date){

		String sql = "select " + ec12 + " from " + curve + " where GROUP_ID = " + groupId + " and "
					+ "EC_DATA_TYPE = " +  ecDataType + " and "
					+ "DATA_DATE =  to_date('" + date + "','yyyy-mm-dd')";
		//System.out.println(sql);
		return sql;
	}
	
	
//	private void getInput(int group_id, Date inputDate) throws Exception
//	{
//		initParam();
//		
//		Class.forName(oracle_driver);
//		try(
//				Connection oracle_conn = DriverManager.getConnection(oracle_url 
//						, oracle_user , oracle_pass);
//				
//				Statement stmt = oracle_conn.createStatement();)
//		{
//			String sqlStr, fieldStr, dateStr;
//			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//			
//			System.out.println(inputDate.getYear() + " " + inputDate.getMonth() + " " + inputDate.getDay() + " "
//					+ inputDate.getHours() + " " + inputDate.getMinutes());
//			
//			
//			if(inputDate.getHours()==0 && inputDate.getMinutes() < 7)
//			{
//				Date dBefore = new Date();
//				fieldStr = "" + 288;
//				Calendar calendar = Calendar.getInstance(); 
//				calendar.setTime(inputDate);
//				calendar.add(Calendar.DAY_OF_MONTH, -1);  
//				dBefore = calendar.getTime();   
//				dateStr = formatter.format(dBefore);
//			}
//			else
//			{
//				fieldStr = "" + (inputDate.getHours()* 12 + (inputDate.getMinutes() - 2)/5);
//				dateStr = formatter.format(inputDate);
//			}
//			
//			sqlStr = "select EC_QUALITY_" + fieldStr
//					+ " from NXGL.EC_D_QUALITY_CURVE where GROUP_ID = ";
//			sqlStr += group_id + " and EC_DATA_TYPE = 7 and DATA_DATE =  to_date('";
//			sqlStr += dateStr + "','yyyy-mm-dd') ";
//			System.out.println(sqlStr);
//		}
//	}
	
	
	public static void main(String[] args)throws Exception
	{
		// TODO Auto-generated method stub
		//EE test = new EE();
		DEMO a = new DEMO();
		System.out.println("123... ");
//		
//		a.test1();
//		System.out.println();
//		a.test2();
//		System.out.println();
//		
//		EE b = EE.getEE(456);
//		EE c = EE.getEE(789);
//
//		System.out.println(b.testoutput());
//		System.out.println(b.testoutput1());
		
		
//		double[] testInput = new double[10];
//		
//		testInput[0] = 0.05;
//		testInput[1] = 0.003;
//		testInput[2] = 0.994;
//		testInput[3] = 0.018;
//		testInput[4] = 0.18;
//		testInput[5] = 0.8;
//		testInput[6] = 0.92;
//		testInput[7] = 0.52;
//		testInput[8] = 0.43;
//		testInput[9] = 1.12;
//		
//		
//		System.out.println(c.getEEDegree(testInput));
		
		
		
		Date testDate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.set(2017, 3, 1, 1, 6, 7);
		
		testDate = calendar.getTime();
		System.out.println(testDate);
		a.getInput(27000008, testDate);
		
		System.out.println(a);
		
		
	}
	
	//ORACLE����׼��
	
	
	//��һ���������쳣

}
