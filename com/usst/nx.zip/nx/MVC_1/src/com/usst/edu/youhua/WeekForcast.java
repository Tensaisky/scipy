package com.usst.edu.youhua;

import static org.junit.Assert.*;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.junit.Before;
import org.junit.Test;

import com.sun.xml.internal.ws.message.DataHandlerAttachment;
import com.sun.xml.internal.ws.spi.db.DatabindingException;
import com.usst.edu.JdbcUtils.JdbcUtils;
import com.usst.edu.doman.SvmData;
import com.usst.edu.doman.longTerm;
import com.usst.edu.svm.LibSvmTest;

import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import libsvm.svm_parameter;
import libsvm.svm_problem;
public class WeekForcast {

	@Test
	public void test() {
		LocalDate date = LocalDate.of(2011, 1, 1);
		
		System.out.println(date);
		
	}
	
	@Test
	public void testWrite () {
		double[] predictResult = write(2012,3);
	}
	
	public double[] write(int year, int month){
		
		LocalDate date1 = LocalDate.of(year, month, 1);
		LocalDate date = LocalDate.of(2011, 3, 7);
		int monthRange = date1.lengthOfMonth();
		longTerm[][] longTerms = new longTerm[7][95];
		double[][] max = new double[7][5];
		double[][] min = new double[7][5];
		
		longTerm[] predictData = new longTerm[monthRange];
		
		for(int i = 0; i < monthRange; i++) {
			longTerm lt = new longTerm();
			getSql(date1, lt);
			//System.out.println(date1 +": "+lt.getTodayMax());
			predictData[i] = lt;
			date1 = date1.plusDays(1);
		}
		
		for(int i = 0; i < longTerms[0].length; i++) {
			//longTerms[i] = new longTerm[date.lengthOfMonth()];
			for(int j = 0; j < 7; j++) {
				longTerm lt = new longTerm();
				getSql(date, lt);
				longTerms[j][i] = lt;
				//System.out.println(date + ": " +longTerms[j][i].getTodayMax());
				date = date.plusDays(1);
			}
		}
		
	//	System.out.println(">> " + longTerms[16][21].getTodayMax() + " : " + longTerms[24][21].getTodayMax() + " : " + longTerms[25][21].getTodayMax() + " : " + longTerms[26][21].getTodayMax());

		max = getMax(longTerms);
		min = getMin(longTerms);
		

		for (int i = 0; i < longTerms.length; i++) {
			for(int k = 0; k < longTerms[0].length; k++) {
				retreat(longTerms[i][k], max[i], min[i]);
			}
		}
		
		LocalDate date3 = LocalDate.of(year, month, 1);
		for(int i = 0; i < predictData.length; i++) {
			int week = date3.getDayOfWeek().getValue();
			retreat(predictData[i], max[week-1], min[week-1]);
			date3.plusDays(1);
		}
		//System.out.println(">> " + longTerms[16][21].getTodayMax() + " : " + longTerms[24][21].getTodayMax() + " : " + longTerms[25][21].getTodayMax() + " : " + longTerms[26][21].getFiveWeekMax());
		
		svm_node[][][] datas = new svm_node[longTerms.length][longTerms[0].length][29];
		double[][] labels = new double[longTerms.length][longTerms[0].length];
		for(int i = 0; i < longTerms.length; i++) {
			for(int j = 0; j < longTerms[0].length; j++) {
				
				labels[i][j] = longTerms[i][j].getTodayMax();
				
				datas[i][j][0] = new svm_node();
				datas[i][j][0].index = 0;
				datas[i][j][0].value = (longTerms[i][j].istSuType() == true ? 1 : 0);
				
				datas[i][j][1] = new svm_node();
				datas[i][j][1].index = 1;
				datas[i][j][1].value = (longTerms[i][j].istSaType() == true ? 1 : 0);
				
				datas[i][j][2] = new svm_node();
				datas[i][j][2].index = 2;
				datas[i][j][2].value = (longTerms[i][j].istStartType() == true ? 1 : 0);
				
				datas[i][j][3] = new svm_node();
				datas[i][j][3].index = 3;
				datas[i][j][3].value =  (longTerms[i][j].istMidType() == true ? 1 : 0);
				
				datas[i][j][4] = new svm_node();
				datas[i][j][4].index = 4;
				datas[i][j][4].value = (longTerms[i][j].istLateType() == true ? 1 : 0);
				
				datas[i][j][5] = new svm_node();
				datas[i][j][5].index = 5;
				datas[i][j][5].value = (longTerms[i][j].isfSuType() == true ? 1 : 0);
				
				datas[i][j][6] = new svm_node();
				datas[i][j][6].index = 6;
				datas[i][j][6].value = (longTerms[i][j].isfSaType() == true ? 1 : 0);
				
				datas[i][j][7] = new svm_node();
				datas[i][j][7].index = 7;
				datas[i][j][7].value = (longTerms[i][j].isfStartType() == true ? 1 : 0);
				
				datas[i][j][8] = new svm_node();
				datas[i][j][8].index = 8;
				datas[i][j][8].value =  (longTerms[i][j].isfMidType() == true ? 1 : 0);
				
				datas[i][j][9] = new svm_node();
				datas[i][j][9].index = 9;
				datas[i][j][9].value = (longTerms[i][j].isfLateType() == true ? 1 : 0);
				
				datas[i][j][10] = new svm_node();
				datas[i][j][10].index = 10;
				datas[i][j][10].value = longTerms[i][j].getFiveWeekMax();
				
				datas[i][j][11] = new svm_node();
				datas[i][j][11].index = 11;
				datas[i][j][11].value = (longTerms[i][j].issSuType() == true ? 1 : 0);
				
				datas[i][j][12] = new svm_node();
				datas[i][j][12].index = 12;
				datas[i][j][12].value = (longTerms[i][j].issSaType() == true ? 1 : 0);
				
				datas[i][j][13] = new svm_node();
				datas[i][j][13].index = 13;
				datas[i][j][13].value = (longTerms[i][j].issStartType() == true ? 1 : 0);
				
				datas[i][j][14] = new svm_node();
				datas[i][j][14].index = 14;
				datas[i][j][14].value =  (longTerms[i][j].issMidType() == true ? 1 : 0);
				
				datas[i][j][15] = new svm_node();
				datas[i][j][15].index = 15;
				datas[i][j][15].value = (longTerms[i][j].issLateType() == true ? 1 : 0);
				
				datas[i][j][16] = new svm_node();
				datas[i][j][16].index = 16;
				datas[i][j][16].value = longTerms[i][j].getSixWeekMax();
				
				datas[i][j][17] = new svm_node();
				datas[i][j][17].index = 17;
				datas[i][j][17].value = (longTerms[i][j].isSvSuType() == true ? 1 : 0);
				
				datas[i][j][18] = new svm_node();
				datas[i][j][18].index = 18;
				datas[i][j][18].value = (longTerms[i][j].isSvSaType() == true ? 1 : 0);
				
				datas[i][j][19] = new svm_node();
				datas[i][j][19].index = 19;
				datas[i][j][19].value = (longTerms[i][j].isSvStartType() == true ? 1 : 0);
				
				datas[i][j][20] = new svm_node();
				datas[i][j][20].index = 20;
				datas[i][j][20].value =  (longTerms[i][j].isSvMidType() == true ? 1 : 0);
				
				datas[i][j][21] = new svm_node();
				datas[i][j][21].index = 21;
				datas[i][j][21].value = (longTerms[i][j].isSvLateType() == true ? 1 : 0);
				
				datas[i][j][22] = new svm_node();
				datas[i][j][22].index = 22;
				datas[i][j][22].value = longTerms[i][j].getSevenWeekMax();
				
				datas[i][j][23] = new svm_node();
				datas[i][j][23].index = 23;
				datas[i][j][23].value = (longTerms[i][j].iseSuType() == true ? 1 : 0);
				
				datas[i][j][24] = new svm_node();
				datas[i][j][24].index = 24;
				datas[i][j][24].value = (longTerms[i][j].iseSaType() == true ? 1 : 0);
				
				datas[i][j][25] = new svm_node();
				datas[i][j][25].index = 25;
				datas[i][j][25].value = (longTerms[i][j].iseStartType() == true ? 1 : 0);
				
				datas[i][j][26] = new svm_node();
				datas[i][j][26].index = 26;
				datas[i][j][26].value =  (longTerms[i][j].iseMidType() == true ? 1 : 0);
				
				datas[i][j][27] = new svm_node();
				datas[i][j][27].index = 27;
				datas[i][j][27].value = (longTerms[i][j].iseLateType() == true ? 1 : 0);
				
				datas[i][j][28] = new svm_node();
				datas[i][j][28].index = 28;
				datas[i][j][28].value = longTerms[i][j].getEightWeekMax();
			}
		}
		
		svm_model[] models = new svm_model[longTerms.length];
		
		svm_parameter param = new svm_parameter();
        param.svm_type = svm_parameter.NU_SVR;
        param.kernel_type = svm_parameter.LINEAR;
        param.C = 40;
        param.cache_size = 100;
        param.eps = 1e-3;
        param.nu = 0.5;
        param.degree = 3;
		param.gamma = 0;	// 1/num_features
		param.coef0 = 0;
		param.p = 0.1;
		param.shrinking = 1;
		param.probability = 0;
		param.nr_weight = 0;
		
		for(int a = 0; a < longTerms.length; a++) {
			svm_problem problem = new svm_problem();
			problem.l = longTerms[0].length;
			problem.x = datas[a];
			problem.y = labels[a];    
	        //System.out.println(svm.svm_check_parameter(problem, param));
	        models[a] = svm.svm_train(problem, param);
		}
        
		double[] result = new double[monthRange];
		double[] labelData = new double[monthRange];
		
		LocalDate date2 = LocalDate.of(year, month, 1);
		
		for(int k = 0; k < monthRange; k++) {
			
			int week = date2.getDayOfWeek().getValue();
			
			svm_node node0 = new svm_node();
			node0.index = 0;
			node0.value = (predictData[k].istSuType() == true ? 1 : 0);
			
			svm_node node1 = new svm_node();
			node1.index = 1;
			node1.value = (predictData[k].istSaType() == true ? 1 : 0);
			
			svm_node node2 = new svm_node();
			node2.index = 2;
			node2.value = (predictData[k].istStartType() == true ? 1 : 0);
			
			svm_node node3 = new svm_node();
			node3.index = 3;
			node3.value =  (predictData[k].istMidType() == true ? 1 : 0);
			
			svm_node node4 = new svm_node();
			node4.index = 4;
			node4.value = (predictData[k].istLateType() == true ? 1 : 0);
			
			svm_node node5 = new svm_node();
			node5.index = 5;
			node5.value = (predictData[k].isfSuType() == true ? 1 : 0);
			
			svm_node node6 = new svm_node();
			node6.index = 6;
			node6.value = (predictData[k].isfSaType() == true ? 1 : 0);
			
			svm_node node7 = new svm_node();
			node7.index = 7;
			node7.value = (predictData[k].isfStartType() == true ? 1 : 0);
			
			svm_node node8 = new svm_node();
			node8.index = 8;
			node8.value =  (predictData[k].isfMidType() == true ? 1 : 0);
			
			svm_node node9 = new svm_node();
			node9.index = 9;
			node9.value = (predictData[k].isfLateType() == true ? 1 : 0);
			
			svm_node node10 = new svm_node();
			node10.index = 10;
			node10.value = predictData[k].getFiveWeekMax();
			
			svm_node node11 = new svm_node();
			node11.index = 11;
			node11.value = (predictData[k].issSuType() == true ? 1 : 0);
			
			svm_node node12 = new svm_node();
			node12.index = 12;
			node12.value = (predictData[k].issSaType() == true ? 1 : 0);
			
			svm_node node13 = new svm_node();
			node13.index = 13;
			node13.value = (predictData[k].issStartType() == true ? 1 : 0);
			
			svm_node node14 = new svm_node();
			node14.index = 14;
			node14.value =  (predictData[k].issMidType() == true ? 1 : 0);
			
			svm_node node15 = new svm_node();
			node15.index = 15;
			node15.value = (predictData[k].issLateType() == true ? 1 : 0);
			
			svm_node node16 = new svm_node();
			node16.index = 16;
			node16.value = predictData[k].getSixWeekMax();
			
			svm_node node17 = new svm_node();
			node17.index = 17;
			node17.value = (predictData[k].isSvSuType() == true ? 1 : 0);
			
			svm_node node18 = new svm_node();
			node18.index = 18;
			node18.value = (predictData[k].isSvSaType() == true ? 1 : 0);
			
			svm_node node19 = new svm_node();
			node19.index = 19;
			node19.value = (predictData[k].isSvStartType() == true ? 1 : 0);
			
			svm_node node20 = new svm_node();
			node20.index = 20;
			node20.value =  (predictData[k].isSvMidType() == true ? 1 : 0);
			
			svm_node node21 = new svm_node();
			node21.index = 21;
			node21.value = (predictData[k].isSvLateType() == true ? 1 : 0);
			
			svm_node node22 = new svm_node();
			node22.index = 22;
			node22.value = predictData[k].getSevenWeekMax();
			
			svm_node node23 = new svm_node();
			node23.index = 23;
			node23.value = (predictData[k].iseSuType() == true ? 1 : 0);
			
			svm_node node24 = new svm_node();
			node24.index = 24;
			node24.value = (predictData[k].iseSaType() == true ? 1 : 0);
			
			svm_node node25 = new svm_node();
			node25.index = 25;
			node25.value = (predictData[k].iseStartType() == true ? 1 : 0);
			
			svm_node node26 = new svm_node();
			node26.index = 26;
			node26.value =  (predictData[k].iseMidType() == true ? 1 : 0);
			
			svm_node node27 = new svm_node();
			node27.index = 27;
			node27.value = (predictData[k].iseLateType() == true ? 1 : 0);
			
			svm_node node28 = new svm_node();
			node28.index = 28;
			node28.value = predictData[k].getEightWeekMax();
			
			svm_node[] pc = {node0,node1,node2,node3,node4,node5,node6,node7,node8,node9,node10,node11,node12,node13,node14,node15,node16,node17,node18,node19,node20,node21,node22,node23,node24,node25,node26,node27,node28};
			result[k] = svm.svm_predict(models[week-1], pc);
			result[k] = LibSvmTest.rescale(max[week-1][0], min[week-1][0], result[k]);
			
			labelData[k] = predictData[k].getTodayMax();
			labelData[k] = LibSvmTest.rescale(max[week-1][0], min[week-1][0], labelData[k]);
			
			date2 = date2.plusDays(1);
		}
		
		double ss = 0;
		
		for(int i = 0; i < monthRange; i++) {
			System.out.println(result[i] + " : " + labelData[i]);
		}
		
		for(int k = 0; k < monthRange; k++) {
			ss += Math.abs((result[k] - labelData[k]))/labelData[k];
		}
//		System.out.println(ss);
		System.out.println(1-ss/monthRange);
		
		return result;
		
	}
	
	public void retreat(longTerm lt, double[] max, double[] min) {
		
		if(lt.getTodayMax() == min[0]){
			lt.setTodayMax(0);
		}else if(lt.getTodayMax()== max[0]) {
			lt.setTodayMax(1);
		}else{
			lt.setTodayMax((lt.getTodayMax() - min[0])/(max[0] - min[0]));
		}
		
		if(lt.getFiveWeekMax() == min[1]){
			lt.setFiveWeekMax(0);
		}else if(lt.getFiveWeekMax() == max[1]) {
			lt.setFiveWeekMax(1);
		}else{
			lt.setFiveWeekMax((lt.getFiveWeekMax() - min[1])/(max[1] - min[1]));
		}
		
		if(lt.getSixWeekMax() == min[2]){
			lt.setSixWeekMax(0);
		}else if(lt.getSixWeekMax() == max[2]) {
			lt.setSixWeekMax(1);
		}else{
			lt.setSixWeekMax((lt.getSixWeekMax() - min[2])/(max[2] - min[2]));
		}
		
		if(lt.getSevenWeekMax() == min[3]){
			lt.setSevenWeekMax(0);
		}else if(lt.getSevenWeekMax() == max[3]) {
			lt.setSevenWeekMax(1);
		}else{
			lt.setSevenWeekMax((lt.getSevenWeekMax() - min[3])/(max[3] - min[3]));
		}
		
		if(lt.getEightWeekMax() == min[4]){
			lt.setEightWeekMax(0);
		}else if(lt.getEightWeekMax() == max[4]) {
			lt.setEightWeekMax(1);
		}else{
			lt.setEightWeekMax((lt.getEightWeekMax() - min[4])/(max[4] - min[4]));
		}
		
	}
	
	public double[][] getMax(longTerm[][] lts) {
		double[][] label = new double[lts.length][lts[0].length];
		double[][] feature = new double[lts.length][lts[0].length];
		double[][] feature2 = new double[lts.length][lts[0].length];
		double[][] feature3 = new double[lts.length][lts[0].length];
		double[][] feature4 = new double[lts.length][lts[0].length];
		
		double[][] res = new double[lts.length][5];
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				label[i][k] = lts[i][k].getTodayMax();
			}
			res[i][0] = max(label[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature[i][k] = lts[i][k].getFiveWeekMax();
			}
			res[i][1] = max(feature[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature2[i][k] = lts[i][k].getSixWeekMax();
			}
			res[i][2] = max(feature2[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature3[i][k] = lts[i][k].getSevenWeekMax();
			}
			res[i][3] = max(feature3[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature4[i][k] = lts[i][k].getEightWeekMax();
			}
			res[i][4] = max(feature4[i]);
		}
		
		return res;
	}
	
	public double max(double[] data) {
		double max = 0;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] > max) {
				max = data[i];
			}
		}
		
		return max;
	}
	
	public double[][] getMin(longTerm[][] lts) {
		double[][] label = new double[lts.length][lts[0].length];
		double[][] feature = new double[lts.length][lts[0].length];
		double[][] feature2 = new double[lts.length][lts[0].length];
		double[][] feature3 = new double[lts.length][lts[0].length];
		double[][] feature4 = new double[lts.length][lts[0].length];
		
		double[][] res = new double[lts.length][5];
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				label[i][k] = lts[i][k].getTodayMax();
			}
			res[i][0] = min(label[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature[i][k] = lts[i][k].getFiveWeekMax();
			}
			res[i][1] = min(feature[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature2[i][k] = lts[i][k].getSixWeekMax();
			}
			res[i][2] = min(feature2[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature3[i][k] = lts[i][k].getSevenWeekMax();
			}
			res[i][3] = min(feature3[i]);
		}
		
		for(int i = 0; i < lts.length; i++) {
			for(int k = 0; k < lts[0].length; k++) {
				feature4[i][k] = lts[i][k].getEightWeekMax();
			}
			res[i][4] = min(feature4[i]);
		}
		
		return res;
	}
	
	public double min(double[] data) {
		double min = 999999;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] < min) {
				min = data[i];
			}
		}
		
		return min;
	}
	
	private void write(BufferedWriter bw, List<SvmData> list) throws IOException {
		SvmData sd;
		for(int i = 0; i < list.size(); i++){
			sd = list.get(i);
			bw.write(sd.getLt() + "\t");
			bw.write("1:" + (sd.isD()==true?1:0) + "\t");
			bw.write("2:" + (sd.isD1()==true?1:0) + "\t");
			bw.write("3:" + sd.getL1ave() + "\t");
			bw.write("4:" + sd.getL1t_1() + "\t");
			bw.write("5:" + sd.getL1t() + "\t");
			bw.write("6:" + sd.getL1t1() + "\t");
			bw.write("7:" + (sd.isD7()==true?1:0) + "\t");
			bw.write("8:" + sd.getL7ave() + "\t");
			bw.write("9:" + sd.getL7t() + "\t");
			bw.newLine();
		}
		bw.flush();
		System.out.println("Completed!");
	}
	
	public void reSetTrain(SvmData svmData, int j) {
		double[] data = new double[7];
		data[0] = svmData.getLt();
		data[1] = svmData.getL1t_1();
		data[2] = svmData.getL1t();
		data[3] = svmData.getL1t1();
		data[4] = svmData.getL1ave();
		data[5] = svmData.getL7t();
		data[6] = svmData.getL7ave();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		double[] maxmin = new double[8];
		
		String sql = "SELECT MAX(average),MIN(average),MAX(EC_ENERGY_" + (j-1) + "),MIN(EC_ENERGY_" + (j-1) + "),MAX(EC_ENERGY_" + j + "),MIN(EC_ENERGY_" + j + "),MAX(EC_ENERGY_" + (j+1) + "),MIN(EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_chuanjiang";

		try{
			connection = JdbcUtils.getConnection();
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				maxmin[0] = resultSet.getDouble(1);
				maxmin[1] = resultSet.getDouble(2);
				maxmin[2] = resultSet.getDouble(3);
				maxmin[3]= resultSet.getDouble(4);
				maxmin[4] = resultSet.getDouble(5);
				maxmin[5] = resultSet.getDouble(6);
				maxmin[6] = resultSet.getDouble(7);
				maxmin[7] = resultSet.getDouble(8);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		getAve(data, maxmin);
		svmData.setLt(data[0]);
		svmData.setL1t_1(data[1]);
		svmData.setL1t(data[2]);
		svmData.setL1t1(data[3]);
		svmData.setL1ave(data[4]);
		svmData.setL7t(data[5]);
		svmData.setL7ave(data[6]);
	}
	
	public void getAve(double[] data, double[] maxmin){
		data[0] =(data[0] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[2] =(data[2] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[5] =(data[5] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[1] =(data[1] - maxmin[3])/(maxmin[2] - maxmin[3]);
		data[3] =(data[3] - maxmin[7])/(maxmin[6] - maxmin[7]);
		data[4] =(data[4] - maxmin[1])/(maxmin[0] - maxmin[1]);
		data[6] =(data[6] - maxmin[1])/(maxmin[0] - maxmin[1]);
	}
	
	@SuppressWarnings("resource")
	public void getSql(LocalDate date, longTerm lt) {
		Connection connection = null; 
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		String sql = null;
		sql = "SELECT SundayType,SaturdayType,holidayStart,holidayMid,holidayLate,Max FROM ec_d_power_max_long WHERE DATA_DATE = ?";
		
		try {
			connection = JdbcUtils.getConnection();
			
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.settSuType(resultSet.getBoolean(1));
				lt.settSaType(resultSet.getBoolean(2));
				lt.settStartType(resultSet.getBoolean(3));
				lt.settMidType(resultSet.getBoolean(4));
				lt.settLateType(resultSet.getBoolean(5));
				lt.setTodayMax(resultSet.getDouble(6));
			}
			
			statement = connection.prepareStatement(sql);
			//System.out.println(date.minusWeeks(5));
			statement.setObject(1, date.minusWeeks(5));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				//System.out.println(date + ": " + resultSet.getDouble(6));
				lt.setfSuType(resultSet.getBoolean(1));
				lt.setfSaType(resultSet.getBoolean(2));
				lt.setfStartType(resultSet.getBoolean(3));
				lt.setfMidType(resultSet.getBoolean(4));
				lt.setfLateType(resultSet.getBoolean(5));
				lt.setFiveWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(6));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.setsSuType(resultSet.getBoolean(1));
				lt.setsSaType(resultSet.getBoolean(2));
				lt.setsStartType(resultSet.getBoolean(3));
				lt.setsMidType(resultSet.getBoolean(4));
				lt.setsLateType(resultSet.getBoolean(5));
				lt.setSixWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(7));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.setSvSuType(resultSet.getBoolean(1));
				lt.setSvSaType(resultSet.getBoolean(2));
				lt.setSvStartType(resultSet.getBoolean(3));
				lt.setSvMidType(resultSet.getBoolean(4));
				lt.setSvLateType(resultSet.getBoolean(5));
				lt.setSevenWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(8));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.seteSuType(resultSet.getBoolean(1));
				lt.seteSaType(resultSet.getBoolean(2));
				lt.seteStartType(resultSet.getBoolean(3));
				lt.seteMidType(resultSet.getBoolean(4));
				lt.seteLateType(resultSet.getBoolean(5));
				lt.setEightWeekMax(resultSet.getDouble(6));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.releaseConnection(connection, statement, resultSet);
		}
		
	}
	
	public String getSql1(LocalDate date, int j) {
		date = date.minusDays(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + (j-1) +",EC_ENERGY_" + j + ",EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_average24_chuanjiang"
				+ " WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
	public String getSql7(LocalDate date, int j) {
		date = date.minusWeeks(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + j + ") FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
}

