package com.usst.edu.doman;

public class Customer {
	
	private long id;
	private String user;
	private int password;
	private String address;
	private String phone;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public Customer() {
		
	}
	
	public Customer(long id, String user, int password, String address, String phone) {
		super();
		this.id = id;
		this.user = user;
		this.password = password;
		this.address = address;
		this.phone = phone;
	}
	
	
	public Customer(String user, String address, String phone) {
		super();
		this.user = user;
		this.address = address;
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", user=" + user + ", password=" + password + ", address=" + address + ", phone="
				+ phone + "]";
	}
	
}
