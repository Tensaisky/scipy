package com.usst.edu.dao.impl;

public class Test {

	public static void main(String[] args) {
		String sql = "INSERT INTO load_forcast_d_2017(CITY_ID,DATA_DATE,GROUP_ID,EC_DATA_TYPE,EC_DATA_POINT,";
		StringBuffer stringBuffer = new StringBuffer(sql);
		for(int i = 1; i < 288; i++){
			stringBuffer.append("EC_ENERGY_" + i + ",");
		}
		stringBuffer.append("EC_ENERGY_288) values(");
		for(int i = 1; i < 293; i++){
			stringBuffer.append("?,");
		}
		stringBuffer.append("?)");
		String sql2 = stringBuffer.toString();
		
		System.out.println(sql2);
		
	}

}
