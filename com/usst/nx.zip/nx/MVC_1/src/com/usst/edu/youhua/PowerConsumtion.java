package com.usst.edu.youhua;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class PowerConsumtion
{

	public double[] getDayData(LocalDate Day)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			// �����ɷ�Χ��9500----10200֮��������
			String sql = "SELECT * FROM mg_power_consumtion where date='" + Day + "' ;";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("total_" + i) / 5;//��ʱ��Ϊ1/5
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}
	
	public double[] getDayDataThree(LocalDate Day)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "SELECT * FROM mg_power_consumtion_load where date='" + Day + "' ;";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("total_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}
}
