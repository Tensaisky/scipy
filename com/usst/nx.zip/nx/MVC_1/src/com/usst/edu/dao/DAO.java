package com.usst.edu.dao;

import java.io.FileInputStream;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.management.RuntimeErrorException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.usst.edu.JdbcUtils.JdbcUtils;
import com.usst.edu.doman.Competence;
import com.usst.edu.doman.EEResult;
import com.usst.edu.doman.Forcast;
import com.usst.edu.doman.GroupInfo;
import com.usst.edu.doman.Shuju;

/**
 * @author mark
 *
 * @param <T>
 */
public class DAO<T> {
	
	private QueryRunner queryRunner=new QueryRunner();
	
//	private Class<T> clazz;
	
	private String oracle_driver;
	private String oracle_url;
	private String oracle_user;
	private String oracle_pass;
	
	public DAO(){
		
//		Type superClass=getClass().getGenericSuperclass();
//		
//		if(superClass instanceof ParameterizedType){
//			ParameterizedType parameterizedType=(ParameterizedType) superClass;
//			//ParameterizedType
//			Type [] typeArgs=parameterizedType.getActualTypeArguments();
//			if(typeArgs!=null&&typeArgs.length>0){
//				if(typeArgs[0] instanceof Class){
//					clazz=(Class<T>) typeArgs[0];
//				}
//			}
//		}
		
	}
	
	public void truncate(String table) throws Exception {
		
		Connection connection=null;
		
		String sql = "truncate " + table;
		
		try{
			connection=JdbcUtils.getConnection();
			queryRunner.update(connection, sql);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
		
	}
	
	public void addNumber(String sql,Forcast bb) throws Exception{
		Connection connection=null;
		double[] cc=bb.getEC_ENERGY();
		try {
			connection=JdbcUtils.getConnection();
			queryRunner.update(connection,sql, bb.getCITY_ID(),bb.getDATA_DATE(),bb.getGROUP_ID(),bb.getEC_DATA_TYPE(),bb.getEC_DATA_POINT(),cc[0],cc[1],cc[2],cc[3],cc[4],cc[5],cc[6],cc[7],cc[8],cc[9],cc[10],cc[11],cc[12],cc[13],cc[14],cc[15],cc[16],cc[17],cc[18],cc[19],cc[20],cc[21],cc[22],cc[23],cc[24],cc[25],cc[26],cc[27],cc[28],cc[29],cc[30],cc[31],cc[32],cc[33],cc[34],cc[35],cc[36],cc[37],cc[38],cc[39]
					,cc[40],cc[41],cc[42],cc[43],cc[44],cc[45],cc[46],cc[47],cc[48],cc[49],cc[50],cc[51],cc[52],cc[53],cc[54],cc[55],cc[56],cc[57],cc[58],cc[59],cc[60],cc[61],cc[62],cc[63],cc[64],cc[65],cc[66],cc[67],cc[68],cc[69],cc[70],cc[71],cc[72],cc[73],cc[74],cc[75],cc[76],cc[77],cc[78],cc[79],cc[80],cc[81],cc[82],cc[83],cc[84],cc[85],cc[86],cc[87],cc[88],cc[89],cc[90],cc[91],cc[92],cc[93],cc[94],cc[95],cc[96],cc[97],cc[98],cc[99],cc[100],cc[101],cc[102],cc[103],cc[104],cc[105],cc[106],cc[107],cc[108],cc[109],cc[110],cc[111],cc[112],cc[113],cc[114],cc[115],cc[116],cc[117],cc[118],cc[119],cc[120],cc[121],cc[122],cc[123],cc[124],cc[125],cc[126],cc[127],cc[128],cc[129],cc[130],cc[131],cc[132],cc[133],cc[134],cc[135],cc[136],cc[137],cc[138],cc[139],cc[140],cc[141],cc[142],cc[143],cc[144],cc[145],cc[146],cc[147],cc[148],cc[149],cc[150],cc[151],cc[152],cc[153],cc[154],cc[155],cc[156],cc[157],cc[158],cc[159],cc[160],cc[161],cc[162],cc[163],cc[164],cc[165],cc[166],cc[167],cc[168],cc[169],cc[170],cc[171],cc[172],cc[173],cc[174],cc[175],cc[176],cc[177],cc[178],cc[179],cc[180],cc[181],cc[182],cc[183],cc[184],cc[185],cc[186],cc[187],cc[188],cc[189],cc[190],cc[192],cc[192],cc[193],cc[194],cc[195],cc[196],cc[197],cc[198],cc[199],cc[200],cc[201],cc[202],cc[203],cc[204],cc[205],cc[206],cc[207],cc[208],cc[209],cc[210],cc[211],cc[212],cc[213],cc[214],cc[215],cc[216],cc[217],cc[218],cc[219],cc[220],cc[221],cc[222],cc[223],cc[224],cc[225],cc[226],cc[227],cc[228],cc[229],cc[230],cc[231],cc[232],cc[233],cc[234],cc[235],cc[236],cc[237],cc[238],cc[239],cc[240],cc[241],cc[242],cc[243],cc[244],cc[245],cc[246],cc[247],cc[248],cc[249],cc[250],cc[251],cc[252],cc[253],cc[254],cc[255],cc[256],cc[257],cc[258],cc[259],cc[260],cc[261],cc[262],cc[263],cc[264],cc[265],cc[266],cc[267],cc[268],cc[269],cc[270],cc[271],cc[272],cc[273],cc[274],cc[275],cc[276],cc[277],cc[278],cc[279],cc[280],cc[281],cc[282],cc[283],cc[284],cc[285],cc[286],cc[287]);			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	public void addNumber2(String sql, LocalDate localDate, double[] cc) throws Exception{
		System.out.println(Arrays.toString(cc));
		Connection connection=null;

		try {
			connection=JdbcUtils.getConnection();
			queryRunner.update(connection,sql, localDate,cc[0],cc[1],cc[2],cc[3],cc[4],cc[5],cc[6],cc[7],cc[8],cc[9],cc[10],cc[11],cc[12],cc[13],cc[14],cc[15],cc[16],cc[17],cc[18],cc[19],cc[20],cc[21],cc[22],cc[23],cc[24],cc[25],cc[26],cc[27],cc[28],cc[29],cc[30],cc[31],cc[32],cc[33],cc[34],cc[35],cc[36],cc[37],cc[38],cc[39]
					,cc[40],cc[41],cc[42],cc[43],cc[44],cc[45],cc[46],cc[47],cc[48],cc[49],cc[50],cc[51],cc[52],cc[53],cc[54],cc[55],cc[56],cc[57],cc[58],cc[59],cc[60],cc[61],cc[62],cc[63],cc[64],cc[65],cc[66],cc[67],cc[68],cc[69],cc[70],cc[71],cc[72],cc[73],cc[74],cc[75],cc[76],cc[77],cc[78],cc[79],cc[80],cc[81],cc[82],cc[83],cc[84],cc[85],cc[86],cc[87],cc[88],cc[89],cc[90],cc[91],cc[92],cc[93],cc[94],cc[95],cc[96],cc[97],cc[98],cc[99],cc[100],cc[101],cc[102],cc[103],cc[104],cc[105],cc[106],cc[107],cc[108],cc[109],cc[110],cc[111],cc[112],cc[113],cc[114],cc[115],cc[116],cc[117],cc[118],cc[119],cc[120],cc[121],cc[122],cc[123],cc[124],cc[125],cc[126],cc[127],cc[128],cc[129],cc[130],cc[131],cc[132],cc[133],cc[134],cc[135],cc[136],cc[137],cc[138],cc[139],cc[140],cc[141],cc[142],cc[143],cc[144],cc[145],cc[146],cc[147],cc[148],cc[149],cc[150],cc[151],cc[152],cc[153],cc[154],cc[155],cc[156],cc[157],cc[158],cc[159],cc[160],cc[161],cc[162],cc[163],cc[164],cc[165],cc[166],cc[167],cc[168],cc[169],cc[170],cc[171],cc[172],cc[173],cc[174],cc[175],cc[176],cc[177],cc[178],cc[179],cc[180],cc[181],cc[182],cc[183],cc[184],cc[185],cc[186],cc[187],cc[188],cc[189],cc[190],cc[192],cc[192],cc[193],cc[194],cc[195],cc[196],cc[197],cc[198],cc[199],cc[200],cc[201],cc[202],cc[203],cc[204],cc[205],cc[206],cc[207],cc[208],cc[209],cc[210],cc[211],cc[212],cc[213],cc[214],cc[215],cc[216],cc[217],cc[218],cc[219],cc[220],cc[221],cc[222],cc[223],cc[224],cc[225],cc[226],cc[227],cc[228],cc[229],cc[230],cc[231],cc[232],cc[233],cc[234],cc[235],cc[236],cc[237],cc[238],cc[239],cc[240],cc[241],cc[242],cc[243],cc[244],cc[245],cc[246],cc[247],cc[248],cc[249],cc[250],cc[251],cc[252],cc[253],cc[254],cc[255],cc[256],cc[257],cc[258],cc[259],cc[260],cc[261],cc[262],cc[263],cc[264],cc[265],cc[266],cc[267],cc[268],cc[269],cc[270],cc[271],cc[272],cc[273],cc[274],cc[275],cc[276],cc[277],cc[278],cc[279],cc[280],cc[281],cc[282],cc[283],cc[284],cc[285],cc[286],cc[287]);			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	public void saveEE(String sql,EEResult eeResult) throws Exception{
		Connection connection=null;
		try {
			connection=JdbcUtils.getConnection();
			queryRunner.update(connection,sql, eeResult.getgROUP_ID(), eeResult.getdATA_TIME(), eeResult.geteE_RST_VALUE());
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	public void insertNumber(String sql,double yy, Date date) throws Exception{
		Connection connection=null;
		try {
			connection=JdbcUtils.getConnection();
			
				queryRunner.update(connection,sql, yy, date);			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	public void deleteAll(String sql) throws Exception{
		Connection connection=null;
		try {
			connection=JdbcUtils.getConnection();
			queryRunner.update(connection, sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	public List<Shuju> getForList(String sql,Object...args){
		
		List<Shuju> yy = new ArrayList<>();
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try {
			connection=JdbcUtils.getConnection();
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			Shuju y;
			int count = 0;
			while(resultSet.next()){
				double[] dub = new double[24];
				for(int i=1; i<25; i++){
					dub[i-1] = resultSet.getDouble(i+3);
				}

				y = new Shuju(resultSet.getDate("DATA_DATE"), resultSet.getInt(2), resultSet.getDouble(3),dub[0],dub[1],dub[2],dub[3],dub[4],dub[5],dub[6],dub[7],dub[8],dub[9],dub[10],dub[11],dub[12],dub[13],dub[14],dub[15],dub[16],dub[17],dub[18],dub[19],dub[20],dub[21],dub[22],dub[23]);
				yy.add(y);
				
				count++;
				if(count == 8) {
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			JdbcUtils.releaseConnection(connection,preparedStatement,resultSet);
		}
		return yy;
	}
	
	public void initParam() throws Exception{
		Properties props = new Properties();
		props.load(new FileInputStream("C:/Users/WORK01/Desktop/nx/MVC_1/src/oracle.ini"));
		oracle_driver = props.getProperty("driver");
		oracle_url = props.getProperty("url");
		oracle_user = props.getProperty("user");
		oracle_pass = props.getProperty("pass");
	}
	
	{
		try{
			initParam();
			Class.forName(oracle_driver);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
public double[] getForList1(LocalDate date){
		
	 double[] yy = new double[24];
     Connection connection=null;
     PreparedStatement preparedStatement=null;
     ResultSet resultSet=null;
     
     String sql = "select "
                     + "EC_ENERGY_1,EC_ENERGY_2,EC_ENERGY_3,EC_ENERGY_4,EC_ENERGY_5,EC_ENERGY_6,EC_ENERGY_7,EC_ENERGY_8,EC_ENERGY_9,EC_ENERGY_10,"
                     + "EC_ENERGY_11,EC_ENERGY_12,EC_ENERGY_13,EC_ENERGY_14,EC_ENERGY_15,EC_ENERGY_16,EC_ENERGY_17,EC_ENERGY_18,EC_ENERGY_19,EC_ENERGY_20,EC_ENERGY_21,EC_ENERGY_22,EC_ENERGY_23,EC_ENERGY_24 "
                     + "from ec_d_power_curve_average24_chuanjiang where "
                     + "DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
    // System.out.println(sql);
     try {
             connection = JdbcUtils.getConnection();
             preparedStatement=connection.prepareStatement(sql);
             //preparedStatement.setDate(1, date);
             resultSet=preparedStatement.executeQuery();
             
             while(resultSet.next()){
                 for(int i=1; i<25; i++){
                         yy[i-1] = resultSet.getDouble(i);
                 }
             }
     } catch (Exception e) {
             
     }finally{
             JdbcUtils.releaseConnection(connection,preparedStatement,resultSet);
     }
     //System.out.println(Arrays.toString(yy));
     return yy;
	}

public double getForList2(String sql,Date date,int group_id){
	
	double yy = 0;
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	
	try {
		connection=JdbcUtils.getConnection();
		preparedStatement=connection.prepareStatement(sql);
		preparedStatement.setDate(1, date);
		preparedStatement.setInt(2,group_id);
		resultSet=preparedStatement.executeQuery();
		
		while(resultSet.next()){
				yy = resultSet.getInt(0);
			}	
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		JdbcUtils.releaseConnection(connection,preparedStatement,resultSet);
	}
	return yy;
}

public <E> E getForValue(String sql,Object...args){
	Connection connection=null;
	try {
		connection=JdbcUtils.getConnection();
		return queryRunner.query(connection, sql, new ScalarHandler<E>(), args);
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		JdbcUtils.releaseConnection(connection);
	}
	return null;
}

public List<Competence> getAllAuthorize(){
	List<Competence> authorizes = new ArrayList<Competence>() ;
	Connection conn = null;
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	
	try {
		conn = JdbcUtils.getConnection();
		preparedStatement = conn.prepareStatement("select * from shu") ;
		resultSet = preparedStatement.executeQuery() ;
		while(resultSet.next()){
			Competence authorize = new Competence() ;
			authorize.setId(resultSet.getInt("id"));
			authorize.setName(resultSet.getString("name")) ;
			authorize.setIsParent(resultSet.getInt("isParent")) ;
			authorize.setOpen(resultSet.getInt("open")) ;
			authorize.setpId(resultSet.getInt("pId")) ;
			authorizes.add(authorize);
		}
	} catch (SQLException e) {
		System.out.println("-----------查询competence失败-------------");
		e.printStackTrace();
	}finally{
		JdbcUtils.releaseConnection(conn,preparedStatement,resultSet);
	}
	return authorizes ;
}

public List<GroupInfo> getAllData(){
	List<GroupInfo> authorizes = new ArrayList<GroupInfo>() ;
	Connection conn = null;
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	
	try {
		conn = JdbcUtils.getConnection();
		preparedStatement = conn.prepareStatement("select * from group_info") ;
		resultSet = preparedStatement.executeQuery() ;
		while(resultSet.next()){
			GroupInfo groupInfo = new GroupInfo() ;
			groupInfo.setId(resultSet.getInt("Group_ID"));
			groupInfo.setGroupCode(resultSet.getString("Group_Code")) ;
			groupInfo.setGroupDesc(resultSet.getString("Group_Desc")) ;
			groupInfo.setGroupType(resultSet.getInt("Group_Type")) ;
			groupInfo.setpId(resultSet.getInt("Group_Parent")) ;
			groupInfo.setIsValid(resultSet.getInt("Is_Valid")) ;
			groupInfo.setIsShow(resultSet.getInt("Is_Show")) ;
			authorizes.add(groupInfo);
		}
	} catch (SQLException e) {
		System.out.println("-----------查询competence失败-------------");
		e.printStackTrace();
	}finally{
		JdbcUtils.releaseConnection(conn,preparedStatement,resultSet);
	}
	return authorizes ;
}

public String getJsonData2(){
	List<GroupInfo> list = getAllData() ;
	StringBuffer json = new StringBuffer("[") ;
	String data = "" ;
	int length = list.size() ;
	for(int i=0;i<length;i++){
		json.append("{id:" + list.get(i).getId() + ",") ;
		//json.append("groupCode:" + list.get(i).getGroupCode() + ",") ;
		json.append("groupCode:\"" + list.get(i).getGroupCode() + "\",");
		json.append("name:\"" + list.get(i).getGroupDesc() + "\",") ;
		json.append("groupType:\"" + list.get(i).getGroupType() + "\",") ;
		//json.append("groupType:\"" + list.get(i).getGroupType() + "\",") ;
		json.append("pId:\"" + list.get(i).getpId() + "\",") ;
		json.append("IsValid:" + list.get(i).getIsValid() + ",") ;
		json.append("IsShow:" + list.get(i).getIsShow() + ",") ;
		//json.append("isValid:\"" + list.get(i).getIsValid() + "\",") ;
		//json.append("isShow:\"" + list.get(i).getIsShow() + "\",") ;
//		if(list.get(i).getIsParent() != 0){
//			json.append("isParent:" + list.get(i).getIsParent() + ",") ;
//		}
//		if(list.get(i).getOpen() != 0){
//			json.append("open:" + list.get(i).getOpen() + ",") ;
//		}
		data = json.substring(0,json.lastIndexOf(",")) + "}," ;
		json = new StringBuffer(data) ;
	}
	data = json.substring(0,json.length()-1) + "]" ;
	System.out.println(data);
	return data ;
}

public String getJsonData(){
	List<Competence> list = getAllAuthorize() ;
	StringBuffer json = new StringBuffer("[") ;
	String data = "" ;
	int length = list.size() ;
	for(int i=0;i<length;i++){
		json.append("{id:" + list.get(i).getId() + ",") ;
		json.append("pId:" + list.get(i).getpId() + ",") ;
		json.append("name:\"" + list.get(i).getName() + "\",") ;
		if(list.get(i).getIsParent() != 0){
			json.append("isParent:" + list.get(i).getIsParent() + ",") ;
		}
		if(list.get(i).getOpen() != 0){
			json.append("open:" + list.get(i).getOpen() + ",") ;
		}
		data = json.substring(0,json.lastIndexOf(",")) + "}," ;
		json = new StringBuffer(data) ;
	}
	data = json.substring(0,json.length()-1) + "]" ;
	System.out.println(data);
	return data ;
}

}

