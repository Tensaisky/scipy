package com.usst.edu.dao.factory;

public class RandomNumberFactory {
	
	private double[] cr = new double[288];
	
	public double[] getDouble(){
		
		for(int i=0; i<288; i++){
			
			int sjs = (int) (Math.random()*1000); 
			double ss = sjs/10.0;
			
			cr[i] = ss;
		}
		
		return cr;
	}
	
}
