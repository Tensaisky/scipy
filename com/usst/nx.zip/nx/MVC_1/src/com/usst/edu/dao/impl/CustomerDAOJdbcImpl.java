package com.usst.edu.dao.impl;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;

import com.usst.edu.dao.CustomerDAO;
import com.usst.edu.dao.DAO;
import com.usst.edu.doman.Competence;
import com.usst.edu.doman.Customer;
import com.usst.edu.doman.EEResult;
import com.usst.edu.doman.Forcast;
import com.usst.edu.doman.Shuju;

import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.Cell;
import jxl.Sheet;

public class CustomerDAOJdbcImpl extends DAO<Forcast> implements CustomerDAO{
	
	private DAO<Competence> dao = new DAO<>();
	
	private double[] db = new double[96];
	private double[][] results = new double[6][96];
	static int counter = 0;
	
	@Override
	public double[][] getAll(LocalDate date) {
		boolean flag = false;

		if(isWeekends(date)){
			date = date.minusWeeks(1);
		}else{
			date = date.minusDays(1);
			while(isWeekends(date)){
				date = date.minusDays(1);
			}
		}
		db = getForList1(date);
		for(int i = 0; i < 96; i++){
			if(db[i] == 0)
				flag = true;
		}
		
		if(!flag){
			System.out.println(counter + ": " + date + " >> " + date.getDayOfWeek());
			//System.out.println(date.getDayOfWeek() + " >> " + counter);

			results[counter++] = db;
			
			if(counter == 6){
				counter = 0;
				return results;
			}
		}
		return getAll(date);	
	}
	
	public boolean isWeekends(LocalDate date){
		if((date.getDayOfWeek() == DayOfWeek.SATURDAY) || (date.getDayOfWeek() == DayOfWeek.SUNDAY))
			return true;
		else
			return false;
	}
	
	public double[] getToday(LocalDate date){
		double[] today = new double[24];
		today = getForList1(date);
		return today;
	}
	
	@Override
	public void save(Forcast bb) throws Exception {
		
		String sql = "INSERT INTO load_forcast_d_2017(CITY_ID,DATA_DATE,GROUP_ID,EC_DATA_TYPE,EC_DATA_POINT,";
		StringBuffer stringBuffer = new StringBuffer(sql);
		for(int i = 1; i < 288; i++){
			stringBuffer.append("EC_ENERGY_" + i + ",");
		}
		stringBuffer.append("EC_ENERGY_288) values(");
		for(int i = 1; i < 293; i++){
			stringBuffer.append("?,");
		}
		stringBuffer.append("?)");
		String sql2 = stringBuffer.toString();
		
		addNumber(sql2, bb);
	}
	
	public double[][] getData() {
		double[][] results = new double[31][288];
    	Workbook book = null;
			try {
				book = Workbook.getWorkbook(new File("C:/Users/Hu/Desktop/1234.xls"));
			} catch (BiffException | IOException e) {
				e.printStackTrace();
			}
        // 获得第一个工作表对象
        Sheet sheet = book.getSheet(0);
        // 得到第一列第一行的单元格
        int columnum = sheet.getColumns();// 得到列数
        int rownum = sheet.getRows();// 得到行数
        Cell cell1;
        String result;
        for (int i = 1; i < 32; i++)// 循环进行读写
        {
            for (int j = 1; j < 289; j++) {
                cell1 = sheet.getCell(i, j);
                result = cell1.getContents();
                //System.out.print(result + " ");
                results[i-1][j-1] = Double.parseDouble(result);
            }
        }
        //System.out.println(Arrays.toString(results[counter]));
        book.close();
        return results;
	}
	
	@Override
	public void saveToPower() throws Exception {
		
		String sql = "INSERT INTO ec_d_power_curve(DATA_DATE,";
		StringBuffer stringBuffer = new StringBuffer(sql);
		for(int i = 1; i < 288; i++){
			stringBuffer.append("EC_ENERGY_" + i + ",");
		}
		stringBuffer.append("EC_ENERGY_288) values(");
		for(int i = 1; i < 289; i++){
			stringBuffer.append("?,");
		}
		stringBuffer.append("?)");
		String sql2 = stringBuffer.toString();
		double[][] results = getData();
		LocalDate localDate = LocalDate.parse("2013-10-01");
		for(int i = 0; i < 31; i++){
			addNumber2(sql2, localDate, results[i]);
			localDate = localDate.plusDays(1);
		}
	}
	
	@Override
	public void delete() throws Exception {
		String sql = "TRUNCATE load_forcast_d_2017";
		deleteAll(sql);
	}

	@Override
	public void update(Double db) {
		
	}


	@Override
	public Double get(Integer id) {
		return null;
	}




	@Override
	public long getCountWithName(String name) {
		return 0;
	}

	@Override
	public List<Shuju> queryAll() {
		String sql="SELECT * FROM ec_d_power_curve_average24_chuanjiang";
		return getForList(sql);
	}

	@Override
	public void insertOne(int id, double y, Date date) throws Exception {
		String sql = "update load_forcast_d_2017 set EC_ENERGY_"+ (id*3) +" =? WHERE DATA_DATE = ?";
		insertNumber(sql, y, date);
	}

	@Override
	public int getForVal(int group_id) {
		String sql = "SELECT EC_EE_VALUE FROM energy_efficiency WHERE GROUP_ID = ?";
		//String date1 = "%" + date + "%";
		return getForValue(sql,group_id);
	}

	@Override
	public void saveEEResult(EEResult er){
		EEResult eeResult = er;
		String sql = "INSERT INTO ee_result(GROUP_ID,DATA_TIME,EE_RST_VALUE) values(?,?,?)";
			
		String table = "ee_result";
		
		try {
				dao.truncate(table);
				saveEE(sql, eeResult);
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

}
