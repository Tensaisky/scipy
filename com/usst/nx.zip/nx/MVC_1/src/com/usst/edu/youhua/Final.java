package com.usst.edu.youhua;

import static org.junit.Assert.*;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.junit.Before;
import org.junit.Test;

import com.sun.xml.internal.ws.message.DataHandlerAttachment;
import com.sun.xml.internal.ws.spi.db.DatabindingException;
import com.usst.edu.JdbcUtils.JdbcUtils;
import com.usst.edu.doman.SvmData;
import com.usst.edu.doman.longTerm;
import com.usst.edu.svm.LibSvmTest;

import javafx.util.converter.LocalDateStringConverter;
import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import libsvm.svm_parameter;
import libsvm.svm_problem;
public class Final {

	@Test
	public void test() {
		LocalDate date = LocalDate.of(2012, 1, 30);
		
		System.out.println(date.plusMonths(2));
		
	}
	
	@Test
	public void testWrite () {
		
//		double[] predictResult = new double[22];
//		
//		for(int i = 3; i < 13; i++) {
//			predictResult[i-3] = forcast(2011, i);
//		}
//		
//		for(int i = 1; i < 13; i++) {
//			predictResult[i+9] = forcast(2012, i);
//		}
//		
//		LocalDate date = LocalDate.of(2011, 3, 1);
//		
//		for(int i = 0; i < 22; i++) {
//			
//			System.out.println(date + ": " +predictResult[i]);
//			
//			date = date.plusMonths(1);
//		}
		
		forcast(2011, 6);
		
	}
	
	public double[][] forcast(int year, int month) {
		
		LocalDate forcastDate = LocalDate.of(year, month, 1); //预测月份
		int monthRange = forcastDate.lengthOfMonth();	//预测月天数
		
		double[] result = new double[monthRange];	//预测结果
		double[] labelData = new double[monthRange];	//预测月标签
		
		longTerm[] modelData = new longTerm[22]; //训练一个模型的数据
		svm_model[] models = new svm_model[31]; //预测一个月的模型
		LocalDate startDate = LocalDate.of(2011, 3, 1); //训练模型数据开始日期
		LocalDate processingDate = null; //迭代取数据日期
		
		double[][] max = new double[31][5]; //每个模型的每个属性的最大值
		double[][] min = new double[31][5]; //最小值
		
		longTerm[] predictData = new longTerm[monthRange]; //预测月数据
		
		double[][] res = new double[3][];
		//训练模型
		for(int i = 0; i < 29; i++) {
			processingDate = LocalDate.of(2011, 3, i+1);
			for(int j = 0; j < modelData.length; j++) {
				longTerm lt = new longTerm();
				getSql(processingDate, lt);
				modelData[j] = lt;
				processingDate = processingDate.plusMonths(1);
			}
			max[i] = getMax(modelData);
			min[i] = getMin(modelData);
			for(int j = 0; j < modelData.length; j++) {
				retreat(modelData[j], max[i], min[i]);
			}
			models[i] = getModels(modelData);
		}
		
		processingDate = LocalDate.of(2011, 3, 30);
		for(int j = 0; j < modelData.length-2; j++) {
			longTerm lt = new longTerm();
			getSql(processingDate, lt);
			modelData[j] = lt;
			processingDate = processingDate.plusMonths(1);
			if(processingDate.equals(LocalDate.of(2012, 1, 30)))
				processingDate = processingDate.plusMonths(2);
		}
		max[29] = getMax(modelData);
		min[29] = getMin(modelData);
		for(int j = 0; j < modelData.length; j++) {
			retreat(modelData[j], max[29], min[29]);
		}
		models[29] = getModels(modelData);
		
		LocalDate[] LastDate ={
							LocalDate.of(2011, 3, 31),
							LocalDate.of(2011, 5, 31),
							LocalDate.of(2011, 7, 31),
							LocalDate.of(2011, 8, 31),
							LocalDate.of(2011, 10, 31),
							LocalDate.of(2011, 12, 31),
							LocalDate.of(2012, 1, 31),
							LocalDate.of(2012, 3, 31),
							LocalDate.of(2012, 5, 31),
							LocalDate.of(2012, 7, 31),
							LocalDate.of(2012, 8, 31),
							LocalDate.of(2012, 10, 31),
							LocalDate.of(2012, 12, 31)
								};
		for(int j = 0; j < 13; j++) {
			longTerm lt = new longTerm();
			getSql(LastDate[j], lt);
			modelData[j] = lt;
		}
		max[30] = getMax(modelData);
		min[30] = getMin(modelData);
		for(int j = 0; j < modelData.length; j++) {
			retreat(modelData[j], max[30], min[30]);
		}
		models[30] = getModels(modelData);
		
		startDate = LocalDate.of(year, month, 1);
		
		//准备预测月数据
		for(int i = 0; i < monthRange; i++) {
			longTerm lt = new longTerm();
			getSql(startDate,lt);
			predictData[i] = lt;
			startDate = startDate.plusDays(1);
		}
		for(int j = 0; j < predictData.length; j++) {
			labelData[j] = predictData[j].getTodayMax();
			retreat(predictData[j], max[j], min[j]);
		}
		
		for(int k = 0; k < monthRange; k++) {
			
			svm_node node0 = new svm_node();
			node0.index = 0;
			node0.value = (predictData[k].istSuType() == true ? 1 : 0);
			
			svm_node node1 = new svm_node();
			node1.index = 1;
			node1.value = (predictData[k].istSaType() == true ? 1 : 0);
			
			svm_node node2 = new svm_node();
			node2.index = 2;
			node2.value = (predictData[k].istStartType() == true ? 1 : 0);
			
			svm_node node3 = new svm_node();
			node3.index = 3;
			node3.value =  (predictData[k].istMidType() == true ? 1 : 0);
			
			svm_node node4 = new svm_node();
			node4.index = 4;
			node4.value = (predictData[k].istLateType() == true ? 1 : 0);
			
			svm_node node5 = new svm_node();
			node5.index = 5;
			node5.value = (predictData[k].isfSuType() == true ? 1 : 0);
			
			svm_node node6 = new svm_node();
			node6.index = 6;
			node6.value = (predictData[k].isfSaType() == true ? 1 : 0);
			
			svm_node node7 = new svm_node();
			node7.index = 7;
			node7.value = (predictData[k].isfStartType() == true ? 1 : 0);
			
			svm_node node8 = new svm_node();
			node8.index = 8;
			node8.value =  (predictData[k].isfMidType() == true ? 1 : 0);
			
			svm_node node9 = new svm_node();
			node9.index = 9;
			node9.value = (predictData[k].isfLateType() == true ? 1 : 0);
			
			svm_node node10 = new svm_node();
			node10.index = 10;
			node10.value = predictData[k].getFiveWeekMax();
			
			svm_node node11 = new svm_node();
			node11.index = 11;
			node11.value = (predictData[k].issSuType() == true ? 1 : 0);
			
			svm_node node12 = new svm_node();
			node12.index = 12;
			node12.value = (predictData[k].issSaType() == true ? 1 : 0);
			
			svm_node node13 = new svm_node();
			node13.index = 13;
			node13.value = (predictData[k].issStartType() == true ? 1 : 0);
			
			svm_node node14 = new svm_node();
			node14.index = 14;
			node14.value =  (predictData[k].issMidType() == true ? 1 : 0);
			
			svm_node node15 = new svm_node();
			node15.index = 15;
			node15.value = (predictData[k].issLateType() == true ? 1 : 0);
			
			svm_node node16 = new svm_node();
			node16.index = 16;
			node16.value = predictData[k].getSixWeekMax();
			
			svm_node node17 = new svm_node();
			node17.index = 17;
			node17.value = (predictData[k].isSvSuType() == true ? 1 : 0);
			
			svm_node node18 = new svm_node();
			node18.index = 18;
			node18.value = (predictData[k].isSvSaType() == true ? 1 : 0);
			
			svm_node node19 = new svm_node();
			node19.index = 19;
			node19.value = (predictData[k].isSvStartType() == true ? 1 : 0);
			
			svm_node node20 = new svm_node();
			node20.index = 20;
			node20.value =  (predictData[k].isSvMidType() == true ? 1 : 0);
			
			svm_node node21 = new svm_node();
			node21.index = 21;
			node21.value = (predictData[k].isSvLateType() == true ? 1 : 0);
			
			svm_node node22 = new svm_node();
			node22.index = 22;
			node22.value = predictData[k].getSevenWeekMax();
			
			svm_node node23 = new svm_node();
			node23.index = 23;
			node23.value = (predictData[k].iseSuType() == true ? 1 : 0);
			
			svm_node node24 = new svm_node();
			node24.index = 24;
			node24.value = (predictData[k].iseSaType() == true ? 1 : 0);
			
			svm_node node25 = new svm_node();
			node25.index = 25;
			node25.value = (predictData[k].iseStartType() == true ? 1 : 0);
			
			svm_node node26 = new svm_node();
			node26.index = 26;
			node26.value =  (predictData[k].iseMidType() == true ? 1 : 0);
			
			svm_node node27 = new svm_node();
			node27.index = 27;
			node27.value = (predictData[k].iseLateType() == true ? 1 : 0);
			
			svm_node node28 = new svm_node();
			node28.index = 28;
			node28.value = predictData[k].getEightWeekMax();
			
			svm_node[] pc = {node0,node1,node2,node3,node4,node5,node6,node7,node8,node9,node10,node11,node12,node13,node14,node15,node16,node17,node18,node19,node20,node21,node22,node23,node24,node25,node26,node27,node28};
			result[k] = svm.svm_predict(models[k], pc);
			result[k] = LibSvmTest.rescale(max[k][0], min[k][0], result[k]);
			
			result[k] = (int)(result[k] * 100)/100.0;
//			labelData[k] = predictData[k].getTodayMax();
//			labelData[k] = LibSvmTest.rescale(max[k][0], min[k][0], labelData[k]);
			
			startDate = startDate.plusDays(1);
		}
		
		double ss = 0;
		
		for(int i = 0; i < monthRange; i++) {
			System.out.println(result[i] + " : " + labelData[i]);
		}
		
		for(int k = 0; k < monthRange; k++) {
			ss += Math.abs((result[k] - labelData[k]))/labelData[k];
		}
		System.out.println(1-ss/monthRange);
		
		double[] acc = new double[1];
		acc[0] = (int)((1-ss/monthRange) * 10000)/100.0;
		
		res[0] = labelData;
		res[1] = result;
		res[2] = acc;
		//return (1-ss/monthRange);
		return res;
	}
	
	public svm_model getModels(longTerm[] modelData) {
		
		svm_model model = new svm_model();
		
		svm_node[][] datas = new svm_node[modelData.length][29];
		double[] labels = new double[modelData.length];
		
		for(int i = 0; i < modelData.length; i++) {
			
			labels[i] = modelData[i].getTodayMax();
			
			datas[i][0] = new svm_node();
			datas[i][0].index = 0;
			datas[i][0].value = (modelData[i].istSuType() == true ? 1 : 0);
			
			datas[i][1] = new svm_node();
			datas[i][1].index = 1;
			datas[i][1].value = (modelData[i].istSaType() == true ? 1 : 0);
			
			datas[i][2] = new svm_node();
			datas[i][2].index = 2;
			datas[i][2].value = (modelData[i].istStartType() == true ? 1 : 0);
			
			datas[i][3] = new svm_node();
			datas[i][3].index = 3;
			datas[i][3].value =  (modelData[i].istMidType() == true ? 1 : 0);
			
			datas[i][4] = new svm_node();
			datas[i][4].index = 4;
			datas[i][4].value = (modelData[i].istLateType() == true ? 1 : 0);
			
			datas[i][5] = new svm_node();
			datas[i][5].index = 5;
			datas[i][5].value = (modelData[i].isfSuType() == true ? 1 : 0);
			
			datas[i][6] = new svm_node();
			datas[i][6].index = 6;
			datas[i][6].value = (modelData[i].isfSaType() == true ? 1 : 0);
			
			datas[i][7] = new svm_node();
			datas[i][7].index = 7;
			datas[i][7].value = (modelData[i].isfStartType() == true ? 1 : 0);
			
			datas[i][8] = new svm_node();
			datas[i][8].index = 8;
			datas[i][8].value =  (modelData[i].isfMidType() == true ? 1 : 0);
			
			datas[i][9] = new svm_node();
			datas[i][9].index = 9;
			datas[i][9].value = (modelData[i].isfLateType() == true ? 1 : 0);
			
			datas[i][10] = new svm_node();
			datas[i][10].index = 10;
			datas[i][10].value = modelData[i].getFiveWeekMax();
			
			datas[i][11] = new svm_node();
			datas[i][11].index = 11;
			datas[i][11].value = (modelData[i].issSuType() == true ? 1 : 0);
			
			datas[i][12] = new svm_node();
			datas[i][12].index = 12;
			datas[i][12].value = (modelData[i].issSaType() == true ? 1 : 0);
			
			datas[i][13] = new svm_node();
			datas[i][13].index = 13;
			datas[i][13].value = (modelData[i].issStartType() == true ? 1 : 0);
			
			datas[i][14] = new svm_node();
			datas[i][14].index = 14;
			datas[i][14].value =  (modelData[i].issMidType() == true ? 1 : 0);
			
			datas[i][15] = new svm_node();
			datas[i][15].index = 15;
			datas[i][15].value = (modelData[i].issLateType() == true ? 1 : 0);
			
			datas[i][16] = new svm_node();
			datas[i][16].index = 16;
			datas[i][16].value = modelData[i].getSixWeekMax();
			
			datas[i][17] = new svm_node();
			datas[i][17].index = 17;
			datas[i][17].value = (modelData[i].isSvSuType() == true ? 1 : 0);
			
			datas[i][18] = new svm_node();
			datas[i][18].index = 18;
			datas[i][18].value = (modelData[i].isSvSaType() == true ? 1 : 0);
			
			datas[i][19] = new svm_node();
			datas[i][19].index = 19;
			datas[i][19].value = (modelData[i].isSvStartType() == true ? 1 : 0);
			
			datas[i][20] = new svm_node();
			datas[i][20].index = 20;
			datas[i][20].value =  (modelData[i].isSvMidType() == true ? 1 : 0);
			
			datas[i][21] = new svm_node();
			datas[i][21].index = 21;
			datas[i][21].value = (modelData[i].isSvLateType() == true ? 1 : 0);
			
			datas[i][22] = new svm_node();
			datas[i][22].index = 22;
			datas[i][22].value = modelData[i].getSevenWeekMax();
			
			datas[i][23] = new svm_node();
			datas[i][23].index = 23;
			datas[i][23].value = (modelData[i].iseSuType() == true ? 1 : 0);
			
			datas[i][24] = new svm_node();
			datas[i][24].index = 24;
			datas[i][24].value = (modelData[i].iseSaType() == true ? 1 : 0);
			
			datas[i][25] = new svm_node();
			datas[i][25].index = 25;
			datas[i][25].value = (modelData[i].iseStartType() == true ? 1 : 0);
			
			datas[i][26] = new svm_node();
			datas[i][26].index = 26;
			datas[i][26].value =  (modelData[i].iseMidType() == true ? 1 : 0);
			
			datas[i][27] = new svm_node();
			datas[i][27].index = 27;
			datas[i][27].value = (modelData[i].iseLateType() == true ? 1 : 0);
			
			datas[i][28] = new svm_node();
			datas[i][28].index = 28;
			datas[i][28].value = modelData[i].getEightWeekMax();
		}
		
//		svm_parameter param = new svm_parameter();
//        param.svm_type = svm_parameter.NU_SVR;
//        param.kernel_type = svm_parameter.LINEAR;
//        param.C = 20;
//        param.cache_size = 100;
//        param.eps = 1e-3;
//        param.nu = 0.6;
//        param.degree = 3;
//		param.gamma = 0;	// 1/num_features
//		param.coef0 = 0;
//		param.p = 0.1;
//		param.shrinking = 1;
//		param.probability = 0;
//		param.nr_weight = 0;
		
		svm_parameter param = new svm_parameter();
        param.svm_type = svm_parameter.NU_SVR;
        param.kernel_type = svm_parameter.LINEAR;
        param.C = 10;
        param.cache_size = 100;
        param.eps = 1e-3;
        param.nu = 0.7;
        param.degree = 3;
		param.gamma = 0;	// 1/num_features
		param.coef0 = 0;
		param.p = 0.1;
		param.shrinking = 1;
		param.probability = 0;
		param.nr_weight = 0;
		
		svm_problem problem = new svm_problem();
		problem.l = modelData.length;
		problem.x = datas;
		problem.y = labels;    
        //System.out.println(svm.svm_check_parameter(problem, param));
        model = svm.svm_train(problem, param);
		
		return model;
	}
	
	public void retreat(longTerm lt, double[] max, double[] min) {
		
		if(lt.getTodayMax() == min[0]){
			lt.setTodayMax(0);
		}else if(lt.getTodayMax()== max[0]) {
			lt.setTodayMax(1);
		}else{
			lt.setTodayMax((lt.getTodayMax() - min[0])/(max[0] - min[0]));
		}
		
		if(lt.getFiveWeekMax() == min[1]){
			lt.setFiveWeekMax(0);
		}else if(lt.getFiveWeekMax() == max[1]) {
			lt.setFiveWeekMax(1);
		}else{
			lt.setFiveWeekMax((lt.getFiveWeekMax() - min[1])/(max[1] - min[1]));
		}
		
		if(lt.getSixWeekMax() == min[2]){
			lt.setSixWeekMax(0);
		}else if(lt.getSixWeekMax() == max[2]) {
			lt.setSixWeekMax(1);
		}else{
			lt.setSixWeekMax((lt.getSixWeekMax() - min[2])/(max[2] - min[2]));
		}
		
		if(lt.getSevenWeekMax() == min[3]){
			lt.setSevenWeekMax(0);
		}else if(lt.getSevenWeekMax() == max[3]) {
			lt.setSevenWeekMax(1);
		}else{
			lt.setSevenWeekMax((lt.getSevenWeekMax() - min[3])/(max[3] - min[3]));
		}
		
		if(lt.getEightWeekMax() == min[4]){
			lt.setEightWeekMax(0);
		}else if(lt.getEightWeekMax() == max[4]) {
			lt.setEightWeekMax(1);
		}else{
			lt.setEightWeekMax((lt.getEightWeekMax() - min[4])/(max[4] - min[4]));
		}
		
	}
	
	public double[] getMax(longTerm[] lts) {
		double[] label = new double[lts.length];
		double[] feature = new double[lts.length];
		double[] feature2 = new double[lts.length];
		double[] feature3 = new double[lts.length];
		double[] feature4 = new double[lts.length];
		
		double[] res = new double[5];
		
		for(int i = 0; i < lts.length; i++) {
			label[i] = lts[i].getTodayMax();
			feature[i] = lts[i].getFiveWeekMax();
			feature2[i] = lts[i].getSixWeekMax();
			feature3[i] = lts[i].getSevenWeekMax();
			feature4[i] = lts[i].getEightWeekMax();
		}
		
		res[0] = max(label);
		res[1] = max(feature);
		res[2] = max(feature2);
		res[3] = max(feature3);
		res[4] = max(feature4);
		
		return res;
	}
	
	public double max(double[] data) {
		double max = -9999999;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] > max) {
				max = data[i];
			}
		}
		
		return max;
	}
	
	public double[] getMin(longTerm[] lts) {
		double[] label = new double[lts.length];
		double[] feature = new double[lts.length];
		double[] feature2 = new double[lts.length];
		double[] feature3 = new double[lts.length];
		double[] feature4 = new double[lts.length];
		
		double[] res = new double[5];
		
		for(int i = 0; i < lts.length; i++) {
			label[i] = lts[i].getTodayMax();
			feature[i] = lts[i].getFiveWeekMax();
			feature2[i] = lts[i].getSixWeekMax();
			feature3[i] = lts[i].getSevenWeekMax();
			feature4[i] = lts[i].getEightWeekMax();
		}
		
		res[0] = min(label);
		res[1] = min(feature);
		res[2] = min(feature2);
		res[3] = min(feature3);
		res[4] = min(feature4);
		
		return res;
	}
	
	public double min(double[] data) {
		double min = 9999999;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] < min) {
				min = data[i];
			}
		}
		
		return min;
	}
	
	private void write(BufferedWriter bw, List<SvmData> list) throws IOException {
		SvmData sd;
		for(int i = 0; i < list.size(); i++){
			sd = list.get(i);
			bw.write(sd.getLt() + "\t");
			bw.write("1:" + (sd.isD()==true?1:0) + "\t");
			bw.write("2:" + (sd.isD1()==true?1:0) + "\t");
			bw.write("3:" + sd.getL1ave() + "\t");
			bw.write("4:" + sd.getL1t_1() + "\t");
			bw.write("5:" + sd.getL1t() + "\t");
			bw.write("6:" + sd.getL1t1() + "\t");
			bw.write("7:" + (sd.isD7()==true?1:0) + "\t");
			bw.write("8:" + sd.getL7ave() + "\t");
			bw.write("9:" + sd.getL7t() + "\t");
			bw.newLine();
		}
		bw.flush();
		System.out.println("Completed!");
	}
	
	public void reSetTrain(SvmData svmData, int j) {
		double[] data = new double[7];
		data[0] = svmData.getLt();
		data[1] = svmData.getL1t_1();
		data[2] = svmData.getL1t();
		data[3] = svmData.getL1t1();
		data[4] = svmData.getL1ave();
		data[5] = svmData.getL7t();
		data[6] = svmData.getL7ave();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		double[] maxmin = new double[8];
		
		String sql = "SELECT MAX(average),MIN(average),MAX(EC_ENERGY_" + (j-1) + "),MIN(EC_ENERGY_" + (j-1) + "),MAX(EC_ENERGY_" + j + "),MIN(EC_ENERGY_" + j + "),MAX(EC_ENERGY_" + (j+1) + "),MIN(EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_chuanjiang";

		try{
			connection = JdbcUtils.getConnection();
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				maxmin[0] = resultSet.getDouble(1);
				maxmin[1] = resultSet.getDouble(2);
				maxmin[2] = resultSet.getDouble(3);
				maxmin[3]= resultSet.getDouble(4);
				maxmin[4] = resultSet.getDouble(5);
				maxmin[5] = resultSet.getDouble(6);
				maxmin[6] = resultSet.getDouble(7);
				maxmin[7] = resultSet.getDouble(8);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		getAve(data, maxmin);
		svmData.setLt(data[0]);
		svmData.setL1t_1(data[1]);
		svmData.setL1t(data[2]);
		svmData.setL1t1(data[3]);
		svmData.setL1ave(data[4]);
		svmData.setL7t(data[5]);
		svmData.setL7ave(data[6]);
	}
	
	public void getAve(double[] data, double[] maxmin){
		data[0] =(data[0] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[2] =(data[2] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[5] =(data[5] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[1] =(data[1] - maxmin[3])/(maxmin[2] - maxmin[3]);
		data[3] =(data[3] - maxmin[7])/(maxmin[6] - maxmin[7]);
		data[4] =(data[4] - maxmin[1])/(maxmin[0] - maxmin[1]);
		data[6] =(data[6] - maxmin[1])/(maxmin[0] - maxmin[1]);
	}
	
	@SuppressWarnings("resource")
	public void getSql(LocalDate date, longTerm lt) {
		Connection connection = null; 
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		String sql = null;
		sql = "SELECT SundayType,SaturdayType,holidayStart,holidayMid,holidayLate,Max FROM ec_d_power_max_long WHERE DATA_DATE = ?";
		
		try {
			connection = JdbcUtils.getConnection();
			
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.settSuType(resultSet.getBoolean(1));
				lt.settSaType(resultSet.getBoolean(2));
				lt.settStartType(resultSet.getBoolean(3));
				lt.settMidType(resultSet.getBoolean(4));
				lt.settLateType(resultSet.getBoolean(5));
				lt.setTodayMax(resultSet.getDouble(6));
			}
			
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(5));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.setfSuType(resultSet.getBoolean(1));
				lt.setfSaType(resultSet.getBoolean(2));
				lt.setfStartType(resultSet.getBoolean(3));
				lt.setfMidType(resultSet.getBoolean(4));
				lt.setfLateType(resultSet.getBoolean(5));
				lt.setFiveWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(6));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.setsSuType(resultSet.getBoolean(1));
				lt.setsSaType(resultSet.getBoolean(2));
				lt.setsStartType(resultSet.getBoolean(3));
				lt.setsMidType(resultSet.getBoolean(4));
				lt.setsLateType(resultSet.getBoolean(5));
				lt.setSixWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(7));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.setSvSuType(resultSet.getBoolean(1));
				lt.setSvSaType(resultSet.getBoolean(2));
				lt.setSvStartType(resultSet.getBoolean(3));
				lt.setSvMidType(resultSet.getBoolean(4));
				lt.setSvLateType(resultSet.getBoolean(5));
				lt.setSevenWeekMax(resultSet.getDouble(6));
			}
			statement = connection.prepareStatement(sql);
			statement.setObject(1, date.minusWeeks(8));
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				lt.seteSuType(resultSet.getBoolean(1));
				lt.seteSaType(resultSet.getBoolean(2));
				lt.seteStartType(resultSet.getBoolean(3));
				lt.seteMidType(resultSet.getBoolean(4));
				lt.seteLateType(resultSet.getBoolean(5));
				lt.setEightWeekMax(resultSet.getDouble(6));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.releaseConnection(connection, statement, resultSet);
		}
		
	}
	
	public String getSql1(LocalDate date, int j) {
		date = date.minusDays(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + (j-1) +",EC_ENERGY_" + j + ",EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_average24_chuanjiang"
				+ " WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
	public String getSql7(LocalDate date, int j) {
		date = date.minusWeeks(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + j + ") FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
}

