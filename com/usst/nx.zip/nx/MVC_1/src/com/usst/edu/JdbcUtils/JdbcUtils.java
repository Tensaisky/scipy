package com.usst.edu.JdbcUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class JdbcUtils {
	
	private static DataSource dataSource=null;
	
	static{
		dataSource=new ComboPooledDataSource("mvcapp");
	}
	
	public static void releaseConnection(Connection connection,PreparedStatement preparedStatement,ResultSet resultSet){
		try {
			if(connection!=null){
				connection.close();
			}
			if(preparedStatement!=null){
				preparedStatement.close();
			}
			if(resultSet!=null){
				resultSet.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	
	public static void releaseConnection(Connection connection){
		try {
			if(connection!=null){
				connection.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 

	public static Connection getConnection() throws SQLException{
		return dataSource.getConnection();
	}

}
