package com.usst.edu.customerServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.usst.edu.dao.CustomerDAO;
import com.usst.edu.dao.factory.CustomerDAOFactory;
import com.usst.edu.doman.Forcast;
import com.usst.edu.doman.Shuju;

@WebServlet("/shujuServlet")
public class ShujuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerDAO customerDAO=CustomerDAOFactory.getInstance().getCustomerDAO();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("正在查询数据库所有数据...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		List<Shuju> lists = customerDAO.queryAll();
		JSONObject.DEFFAULT_DATE_FORMAT="yyyy-MM-dd";
		String s = JSONObject.toJSONString(lists, SerializerFeature.WriteMapNullValue,SerializerFeature.DisableCircularReferenceDetect,SerializerFeature.WriteDateUseDateFormat);
		out.print(s);
		
		out.flush();
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public void queryAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		
	}

}
