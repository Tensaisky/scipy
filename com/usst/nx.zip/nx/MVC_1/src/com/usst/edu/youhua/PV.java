package com.usst.edu.youhua;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class PV
{

	public double[] getDayDate(LocalDate date)
	{
		double[] value = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int date1 = 1;
		String sql = "select * from mg_pv_power where id = ?";

		int i = date.getMonthValue();
		if (date.getDayOfMonth() % 2 != 0)
		{
			date1 = 2 * i - 1;
		}
		else
		{
			date1 = 2 * i;
		}

		try
		{
			
			conn = MySQLConn.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, date1);
			rs = stmt.executeQuery();
			while (rs.next())
			{
				for (int j = 0; j < 96; j++)
				{
					value[j] = rs.getDouble(j + 3);
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return value;
	}
}
