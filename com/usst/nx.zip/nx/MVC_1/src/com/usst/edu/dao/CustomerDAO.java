package com.usst.edu.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.usst.edu.doman.Customer;
import com.usst.edu.doman.EEResult;
import com.usst.edu.doman.Forcast;
import com.usst.edu.doman.Shuju;

public interface CustomerDAO {
	
	public double[][] getAll(LocalDate date);
	public double[] getToday(LocalDate date);
	public void save(Forcast db) throws Exception;
	
	public Double get(Integer id);
	public List<Shuju> queryAll();
	public void delete() throws Exception;
	public void insertOne(int id,double y, Date date) throws Exception;
	public void update(Double db);
	public int getForVal(int group_id);
	public void saveEEResult(EEResult er) throws Exception;
	
	/**
	 * @param name
	 * @return
	 */
	public long getCountWithName(String name);
	void saveToPower() throws Exception;
}
