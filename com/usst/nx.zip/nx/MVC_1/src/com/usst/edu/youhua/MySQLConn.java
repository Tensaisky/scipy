package com.usst.edu.youhua;


import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.usst.edu.JdbcUtils.JdbcUtils;

public class MySQLConn {
	private static String driver = null;
	private static String url = null;
	private static String username = null;
	private static String password = null;
//	static{	
//		//ע����������
//		try {
//			
//			Properties props = new Properties();
//			props.load(new FileInputStream("C:/Users/WORK01/Desktop/nx/MVC_1/src/mysql.ini"));
//			driver = props.getProperty("driver");
//			url = props.getProperty("url");
//			username = props.getProperty("username");
//			password = props.getProperty("password");
//			Class.forName(driver);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
		
	/**
	 * ��ȡ���ӷ���
	 */
	public static Connection getConnection(){
//		try {
//			Connection conn = DriverManager.getConnection(url, username, password);
//			return conn;
//		} catch (SQLException e) {
//			e.printStackTrace();
//			throw new RuntimeException(e);
//		}
		
		Connection conn = null;
		try {
			conn = JdbcUtils.getConnection();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return conn;
		
	}
	/**
	 * �ͷ���Դ�ķ���
	 */
	
	public static void close(ResultSet rs,Statement stmt,Connection conn){
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}
}
