package com.usst.edu.doman;

import java.sql.Date;

import com.alibaba.fastjson.annotation.JSONField;


public class Shuju {

	@JSONField(format = "yyyy-MM-dd")
	Date DATA_DATE;
	int DayType;
	double average;
	double EC_ENERGY_1,EC_ENERGY_2,EC_ENERGY_3,EC_ENERGY_4,EC_ENERGY_5,EC_ENERGY_6,EC_ENERGY_7,EC_ENERGY_8,EC_ENERGY_9,EC_ENERGY_10,EC_ENERGY_11,EC_ENERGY_12,EC_ENERGY_13,EC_ENERGY_14,EC_ENERGY_15,EC_ENERGY_16,EC_ENERGY_17,EC_ENERGY_18,EC_ENERGY_19,EC_ENERGY_20,EC_ENERGY_21,EC_ENERGY_22,EC_ENERGY_23,EC_ENERGY_24;
	
	public Date getDATA_DATE() {
		return DATA_DATE;
	}

	public void setDATA_DATE(Date dATA_DATE) {
		DATA_DATE = dATA_DATE;
	}

	public int getDayType() {
		return DayType;
	}

	public void setDayType(int dayType) {
		DayType = dayType;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	public double getEC_ENERGY_1() {
		return EC_ENERGY_1;
	}

	public void setEC_ENERGY_1(double eC_ENERGY_1) {
		EC_ENERGY_1 = eC_ENERGY_1;
	}

	public double getEC_ENERGY_2() {
		return EC_ENERGY_2;
	}

	public void setEC_ENERGY_2(double eC_ENERGY_2) {
		EC_ENERGY_2 = eC_ENERGY_2;
	}

	public double getEC_ENERGY_3() {
		return EC_ENERGY_3;
	}

	public void setEC_ENERGY_3(double eC_ENERGY_3) {
		EC_ENERGY_3 = eC_ENERGY_3;
	}

	public double getEC_ENERGY_4() {
		return EC_ENERGY_4;
	}

	public void setEC_ENERGY_4(double eC_ENERGY_4) {
		EC_ENERGY_4 = eC_ENERGY_4;
	}

	public double getEC_ENERGY_5() {
		return EC_ENERGY_5;
	}

	public void setEC_ENERGY_5(double eC_ENERGY_5) {
		EC_ENERGY_5 = eC_ENERGY_5;
	}

	public double getEC_ENERGY_6() {
		return EC_ENERGY_6;
	}

	public void setEC_ENERGY_6(double eC_ENERGY_6) {
		EC_ENERGY_6 = eC_ENERGY_6;
	}

	public double getEC_ENERGY_7() {
		return EC_ENERGY_7;
	}

	public void setEC_ENERGY_7(double eC_ENERGY_7) {
		EC_ENERGY_7 = eC_ENERGY_7;
	}

	public double getEC_ENERGY_8() {
		return EC_ENERGY_8;
	}

	public void setEC_ENERGY_8(double eC_ENERGY_8) {
		EC_ENERGY_8 = eC_ENERGY_8;
	}

	public double getEC_ENERGY_9() {
		return EC_ENERGY_9;
	}

	public void setEC_ENERGY_9(double eC_ENERGY_9) {
		EC_ENERGY_9 = eC_ENERGY_9;
	}

	public double getEC_ENERGY_10() {
		return EC_ENERGY_10;
	}

	public void setEC_ENERGY_10(double eC_ENERGY_10) {
		EC_ENERGY_10 = eC_ENERGY_10;
	}

	public double getEC_ENERGY_11() {
		return EC_ENERGY_11;
	}

	public void setEC_ENERGY_11(double eC_ENERGY_11) {
		EC_ENERGY_11 = eC_ENERGY_11;
	}

	public double getEC_ENERGY_12() {
		return EC_ENERGY_12;
	}

	public void setEC_ENERGY_12(double eC_ENERGY_12) {
		EC_ENERGY_12 = eC_ENERGY_12;
	}

	public double getEC_ENERGY_13() {
		return EC_ENERGY_13;
	}

	public void setEC_ENERGY_13(double eC_ENERGY_13) {
		EC_ENERGY_13 = eC_ENERGY_13;
	}

	public double getEC_ENERGY_14() {
		return EC_ENERGY_14;
	}

	public void setEC_ENERGY_14(double eC_ENERGY_14) {
		EC_ENERGY_14 = eC_ENERGY_14;
	}

	public double getEC_ENERGY_15() {
		return EC_ENERGY_15;
	}

	public void setEC_ENERGY_15(double eC_ENERGY_15) {
		EC_ENERGY_15 = eC_ENERGY_15;
	}

	public double getEC_ENERGY_16() {
		return EC_ENERGY_16;
	}

	public void setEC_ENERGY_16(double eC_ENERGY_16) {
		EC_ENERGY_16 = eC_ENERGY_16;
	}

	public double getEC_ENERGY_17() {
		return EC_ENERGY_17;
	}

	public void setEC_ENERGY_17(double eC_ENERGY_17) {
		EC_ENERGY_17 = eC_ENERGY_17;
	}

	public double getEC_ENERGY_18() {
		return EC_ENERGY_18;
	}

	public void setEC_ENERGY_18(double eC_ENERGY_18) {
		EC_ENERGY_18 = eC_ENERGY_18;
	}

	public double getEC_ENERGY_19() {
		return EC_ENERGY_19;
	}

	public void setEC_ENERGY_19(double eC_ENERGY_19) {
		EC_ENERGY_19 = eC_ENERGY_19;
	}

	public double getEC_ENERGY_20() {
		return EC_ENERGY_20;
	}

	public void setEC_ENERGY_20(double eC_ENERGY_20) {
		EC_ENERGY_20 = eC_ENERGY_20;
	}

	public double getEC_ENERGY_21() {
		return EC_ENERGY_21;
	}

	public void setEC_ENERGY_21(double eC_ENERGY_21) {
		EC_ENERGY_21 = eC_ENERGY_21;
	}

	public double getEC_ENERGY_22() {
		return EC_ENERGY_22;
	}

	public void setEC_ENERGY_22(double eC_ENERGY_22) {
		EC_ENERGY_22 = eC_ENERGY_22;
	}

	public double getEC_ENERGY_23() {
		return EC_ENERGY_23;
	}

	public void setEC_ENERGY_23(double eC_ENERGY_23) {
		EC_ENERGY_23 = eC_ENERGY_23;
	}

	public double getEC_ENERGY_24() {
		return EC_ENERGY_24;
	}

	public void setEC_ENERGY_24(double eC_ENERGY_24) {
		EC_ENERGY_24 = eC_ENERGY_24;
	}

	@Override
	public String toString() {
		return "Shuju [DATA_DATE=" + DATA_DATE + ", DayType=" + DayType + ", average=" + average + ", EC_ENERGY_1="
				+ EC_ENERGY_1 + ", EC_ENERGY_2=" + EC_ENERGY_2 + ", EC_ENERGY_3=" + EC_ENERGY_3 + ", EC_ENERGY_4="
				+ EC_ENERGY_4 + ", EC_ENERGY_5=" + EC_ENERGY_5 + ", EC_ENERGY_6=" + EC_ENERGY_6 + ", EC_ENERGY_7="
				+ EC_ENERGY_7 + ", EC_ENERGY_8=" + EC_ENERGY_8 + ", EC_ENERGY_9=" + EC_ENERGY_9 + ", EC_ENERGY_10="
				+ EC_ENERGY_10 + ", EC_ENERGY_11=" + EC_ENERGY_11 + ", EC_ENERGY_12=" + EC_ENERGY_12 + ", EC_ENERGY_13="
				+ EC_ENERGY_13 + ", EC_ENERGY_14=" + EC_ENERGY_14 + ", EC_ENERGY_15=" + EC_ENERGY_15 + ", EC_ENERGY_16="
				+ EC_ENERGY_16 + ", EC_ENERGY_17=" + EC_ENERGY_17 + ", EC_ENERGY_18=" + EC_ENERGY_18 + ", EC_ENERGY_19="
				+ EC_ENERGY_19 + ", EC_ENERGY_20=" + EC_ENERGY_20 + ", EC_ENERGY_21=" + EC_ENERGY_21 + ", EC_ENERGY_22="
				+ EC_ENERGY_22 + ", EC_ENERGY_23=" + EC_ENERGY_23 + ", EC_ENERGY_24=" + EC_ENERGY_24 + "]";
	}

	public Shuju(Date dATA_DATE, int dayType, double average, double eC_ENERGY_1, double eC_ENERGY_2,
			double eC_ENERGY_3, double eC_ENERGY_4, double eC_ENERGY_5, double eC_ENERGY_6, double eC_ENERGY_7,
			double eC_ENERGY_8, double eC_ENERGY_9, double eC_ENERGY_10, double eC_ENERGY_11, double eC_ENERGY_12,
			double eC_ENERGY_13, double eC_ENERGY_14, double eC_ENERGY_15, double eC_ENERGY_16, double eC_ENERGY_17,
			double eC_ENERGY_18, double eC_ENERGY_19, double eC_ENERGY_20, double eC_ENERGY_21, double eC_ENERGY_22,
			double eC_ENERGY_23, double eC_ENERGY_24) {
		super();
		DATA_DATE = dATA_DATE;
		DayType = dayType;
		this.average = average;
		EC_ENERGY_1 = eC_ENERGY_1;
		EC_ENERGY_2 = eC_ENERGY_2;
		EC_ENERGY_3 = eC_ENERGY_3;
		EC_ENERGY_4 = eC_ENERGY_4;
		EC_ENERGY_5 = eC_ENERGY_5;
		EC_ENERGY_6 = eC_ENERGY_6;
		EC_ENERGY_7 = eC_ENERGY_7;
		EC_ENERGY_8 = eC_ENERGY_8;
		EC_ENERGY_9 = eC_ENERGY_9;
		EC_ENERGY_10 = eC_ENERGY_10;
		EC_ENERGY_11 = eC_ENERGY_11;
		EC_ENERGY_12 = eC_ENERGY_12;
		EC_ENERGY_13 = eC_ENERGY_13;
		EC_ENERGY_14 = eC_ENERGY_14;
		EC_ENERGY_15 = eC_ENERGY_15;
		EC_ENERGY_16 = eC_ENERGY_16;
		EC_ENERGY_17 = eC_ENERGY_17;
		EC_ENERGY_18 = eC_ENERGY_18;
		EC_ENERGY_19 = eC_ENERGY_19;
		EC_ENERGY_20 = eC_ENERGY_20;
		EC_ENERGY_21 = eC_ENERGY_21;
		EC_ENERGY_22 = eC_ENERGY_22;
		EC_ENERGY_23 = eC_ENERGY_23;
		EC_ENERGY_24 = eC_ENERGY_24;
	}

	public Shuju() {
		super();
	}
	
}
