package com.usst.edu.youhua;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class WindPower
{

	public double[] getDayData(LocalDate d)
	{
		ResultSet rs = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		double EN[] = new double[96];
		int temp = 1;
		int m = d.getMonthValue();
		if (d.getDayOfMonth() % 3 == 1)
		{
			temp = 3 * m - 2;
		}
		else if (d.getDayOfMonth() % 3 == 2)
		{
			temp = 3 * m - 1;
		}
		else if (d.getDayOfMonth() % 3 == 0)
		{
			temp = 3 * m;
		}
		
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "SELECT * FROM mg_wind_power WHERE ID = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, temp);
			rs = stmt.executeQuery();

			while (rs.next())
			{
				String DATA_DATE_Str = rs.getString("DATA_DATE");
				//System.out.println(DATA_DATE_Str);
				for (int i = 0; i < 96; i++)
				{
					EN[i] = rs.getDouble(i + 3);
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return EN;
	}
}