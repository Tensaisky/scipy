package com.usst.edu.customerServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.jni.Local;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.usst.edu.cn.Cc2;
import com.usst.edu.dao.CustomerDAO;
import com.usst.edu.dao.DAO;
import com.usst.edu.dao.factory.CustomerDAOFactory;
import com.usst.edu.dao.factory.RandomNumberFactory;
import com.usst.edu.dao.impl.CustomerDAOJdbcImpl;
import com.usst.edu.doman.Competence;
import com.usst.edu.doman.Customer;
import com.usst.edu.doman.EEResult;
import com.usst.edu.doman.Forcast;
import com.usst.edu.doman.Shuju;
import com.usst.edu.svm.LibSvmTest;
import com.usst.edu.test.JdbcUtilsTest;
import com.usst.edu.youhua.Final;
import com.usst.edu.youhua.MGO_Test;
import com.usst.ee.DEMO;
import com.usst.ee.EE;

import david.ANN.BP.ANN_TEST;

@WebServlet("*.do")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private CustomerDAO customerDAO=CustomerDAOFactory.getInstance().getCustomerDAO();
	private DAO<Competence> dao = new DAO<>();
	
    public CustomerServlet() {
    }

    private void shu2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
    	System.out.println("正在查询目录树...");
    	
    	String webAppRootKey = getServletContext().getRealPath("oracle.ini");
    	//System.out.println(webAppRootKey);
    	
    	response.setContentType("text/javascript;charset=utf-8");
    	response.setCharacterEncoding("utf-8");
    	PrintWriter out = response.getWriter();
    	
    	String shu = dao.getJsonData2();
    	out.print(shu);
    	
    	out.flush();
    	out.close();
    }
    
    private void shu(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
    	System.out.println("正在查询目录树...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
    	
    	String shu = dao.getJsonData();
    	out.print(shu);
		 
		out.flush();
		out.close();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String servletPath=request.getServletPath();
		//System.out.println(servletPath);
		String methodName=servletPath.substring(1);
		methodName=methodName.substring(0, methodName.length()-3);
		//System.out.println(methodName);
		
		try{
			Method method=getClass().getDeclaredMethod(methodName, HttpServletRequest.class,HttpServletResponse.class);
			//System.out.println(method);
			method.invoke(this, request,response);
		}catch(Exception e){
			e.printStackTrace();
			
			response.sendRedirect("error.jsp");
		}
	}
	private void mainServlet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		//System.out.println("aaaaa");
	}
	
	private void zhiFangtu(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		System.out.println("正在评级中...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String date2 = request.getParameter("datez");
		
		double[][] rets = new double[2][];
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		java.util.Date date = df.parse(date2);

		String group_ids = request.getParameter("group_ids");
		String[] group_id1 = group_ids.split(",");

		double eeResult[] = new double[group_id1.length];
		int group_id;
		EE eeForcast = null;
		DEMO demo = new DEMO();
		EEResult ee = null;
		double[] inputData = new double[10];
		double[] errorFlag = new double[group_id1.length];
		for(int i = 0; i < group_id1.length; i++){

			group_id = Integer.parseInt(group_id1[i]);
			
			inputData = demo.getInput(group_id, date);
			
			eeForcast = EE.getEE(group_id);
			eeResult[i] = eeForcast.getEEDegree(inputData);		
			//System.out.println(eeResult[i]);
			
			for(int k = 0; k < 10; k++) {
				if(eeForcast.error[k] == 1)
					errorFlag[i] = 1;
			}
			
			ee = new EEResult(group_id, date, eeResult[i]);
			customerDAO.saveEEResult(ee);
			
		}
		
		for(int i = 0; i < eeResult.length; i++) {
			eeResult[i] = Math.ceil(eeResult[i]);
		}
		
		rets[0] = eeResult;
		rets[1] = errorFlag;
		
		System.out.println(Arrays.toString(rets));
		
		JSONObject.DEFFAULT_DATE_FORMAT="yyyy-MM-dd";
		String s = JSONObject.toJSONString(rets, SerializerFeature.WriteMapNullValue,SerializerFeature.DisableCircularReferenceDetect,SerializerFeature.WriteDateUseDateFormat);
		Thread.sleep(2000);
		
		out.print(s);
		 
		out.flush();
		out.close();
	}
	
	private void shuju(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		System.out.println("正在查询数据库所有数据...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		List<Shuju> lists = customerDAO.queryAll();
		JSONObject.DEFFAULT_DATE_FORMAT="yyyy-MM-dd";
		String s = JSONObject.toJSONString(lists, SerializerFeature.WriteMapNullValue,SerializerFeature.DisableCircularReferenceDetect,SerializerFeature.WriteDateUseDateFormat);
		//System.out.println(s);
		out.print(s);
		 
		out.flush();
		out.close();
	}

	private void midForcast(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		System.out.println("中期符合预测中...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String date1 = request.getParameter("date");
		LocalDate date = LocalDate.parse(date1);
		System.out.println("预测日期： " + date + " 星期： " + date.getDayOfWeek());
		Final forcast = new Final();
		int year = date.getYear();
		int month = date.getMonthValue();
		
		PrintWriter out = response.getWriter();
		
		if(month == 7 || month == 3) {
			year = 2011;
		}else {
			year =2012;
		}
		
		double[][] result = forcast.forcast(year, month);
		
		String s = JSON.toJSONString(result);

		System.out.println(s);
		
		out.print(s);
		
		out.flush();
		out.close();
	}

	
	private void query(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		
		System.out.println("短期符合预测中...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String date1 = request.getParameter("date");
		LocalDate date = LocalDate.parse(date1);
		System.out.println("预测日期： " + date + " 星期： " + date.getDayOfWeek());
		
		int dayOfMonth = date.getDayOfMonth();
		if(dayOfMonth > 29) {
			dayOfMonth = dayOfMonth - 3;
		}
		JdbcUtilsTest jut = new JdbcUtilsTest();
		double[] result = new double[24];
		result = jut.write(dayOfMonth);
		
		PrintWriter out = response.getWriter();
		LocalDate dateT = LocalDate.of(2012, 6, dayOfMonth);
		double[] today = customerDAO.getToday(dateT);
		
		double sum = 0;
		for(int i = 0; i < 24; i++){
			if( today[i] == 0 ){
				sum += 0;
			}else{
				sum += Math.abs(result[i] - today[i])/today[i];
			}
		}
		double average = sum/24;
		//int ave = (int) Math.floor(average);
		//average = average - ave;
		//System.out.println(ave);
		//System.out.println(average);
		double acurite = Math.round((1 - average) * 10000)/100.0;
		
		Thread.sleep(500);
		System.out.println("实际值： " + Arrays.toString(today));
		System.out.println("预测值： " + Arrays.toString(result));
		System.out.println("预测准确率为: " + acurite + "%");
		double[] acc = new double[1];
		acc[0] = acurite;
		
		double[][] all = new double[3][];
		all[0] = result;
		all[1] = today;
		all[2] = acc;
		
		String s = JSON.toJSONString(all);
		//System.out.println(s);
		out.print(s);
		
		out.flush();
		out.close();
	}
	
private void query1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		
		System.out.println("正在查询数据库...");
		
		response.setContentType("text/javascript;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String time = request.getParameter("time");
		//String date1 = request.getParameter("date");
		//SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		//java.util.Date date2 = df.parse(date1);
		//Date date = new Date(date2.getTime());
		
		PrintWriter out = response.getWriter();
		//double[] lists = customerDAO.getAll(date);
		
		//double [] lists1 = new double[96];
		
		//Cc2 cc2 = new Cc2();
		
		//for(int i=0; i<96; i++){
			//lists1[i] = cc2.getDouble(lists[i]);
		//}
		//Thread.sleep(2000);
		String s = JSON.toJSONString(time);
		out.print(s);
		
		out.flush();
		out.close();
	}

private void youhua(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
	
	System.out.println("优化中...");
	
	response.setContentType("text/javascript;charset=utf-8");
	response.setCharacterEncoding("utf-8");
	String time = request.getParameter("time");
	String date = request.getParameter("date");
	LocalDate day = LocalDate.parse(date);
	
	PrintWriter out = response.getWriter();
	
	MGO_Test mt = new MGO_Test();
	double[][] result = mt.out(day);
	
	String s = JSON.toJSONString(result);
	out.print(s);
	
	out.flush();
	out.close();
}
	
	public void insertOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception{
		System.out.println("正在插入一条记录...");
		int id = Integer.parseInt(request.getParameter("id"));
		double y = Double.parseDouble(request.getParameter("y"));
		String date1 = request.getParameter("datet");
		java.sql.Date date=java.sql.Date.valueOf(date1);
		customerDAO.insertOne(id, y, date);
	}

	private void add(HttpServletRequest req, HttpServletResponse resp) throws Exception{
		System.out.println("正在插入数据...");
		
		RandomNumberFactory rnf = new RandomNumberFactory();
		double[] db = rnf.getDouble();

		Timestamp ts = new Timestamp(System.currentTimeMillis());  
        String tsStr = "2017-03-12 11:49:45";  
        try {  
            ts = Timestamp.valueOf(tsStr);  
            System.out.println(ts);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		Forcast forcast = new Forcast(27, ts, 27000001, 100, 288, db); 
		customerDAO.save(forcast);
	}
	
	private void delete(HttpServletRequest req, HttpServletResponse resp) throws Exception{
		
		System.out.println("正在清空数据库...");
		
		customerDAO.delete();
	}
	
	private void error(HttpServletRequest req, HttpServletResponse resp) throws Exception{
		System.out.println("系统出现异常...");
		
//		System.out.println(Arrays.toString(inputData));
		
//		if(inputData != null){
//			for(int j = 0; j < 10; j++){
//				if(inputData[j] == 0)
//					flag = true;
//			}
//		}
		
	//System.out.println(inputData == null);
				
	}

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			doGet(req, resp);
		}
		
}

