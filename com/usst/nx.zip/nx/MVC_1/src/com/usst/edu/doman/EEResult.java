package com.usst.edu.doman;

import java.util.Date;

public class EEResult {
	private int gROUP_ID;
	private Date dATA_TIME;
	private double eE_RST_VALUE;

	
	
	public int getgROUP_ID() {
		return gROUP_ID;
	}

	public void setgROUP_ID(int gROUP_ID) {
		this.gROUP_ID = gROUP_ID;
	}

	public Date getdATA_TIME() {
		return dATA_TIME;
	}

	public void setdATA_TIME(Date dATA_TIME) {
		this.dATA_TIME = dATA_TIME;
	}

	public double geteE_RST_VALUE() {
		return eE_RST_VALUE;
	}

	public void seteE_RST_VALUE(double eE_RST_VALUE) {
		this.eE_RST_VALUE = eE_RST_VALUE;
	}

	public EEResult(int gROUP_ID, Date dATA_TIME, double eE_RST_VALUE) {
		super();
		this.gROUP_ID = gROUP_ID;
		this.dATA_TIME = dATA_TIME;
		this.eE_RST_VALUE = eE_RST_VALUE;
	}
	
	@Override
	public String toString() {
		return "EEResult [gROUP_ID=" + gROUP_ID + ", dATA_TIME=" + dATA_TIME + ", eE_RST_VALUE=" + eE_RST_VALUE + "]";
	}
	public EEResult() {}
	
	
}
