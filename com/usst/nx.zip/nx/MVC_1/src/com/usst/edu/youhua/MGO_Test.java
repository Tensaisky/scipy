package com.usst.edu.youhua;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Arrays;

import sun.util.calendar.LocalGregorianCalendar;

public class MGO_Test
{
	//�Ż����
	private double[] gas_power = new double[96];
	private double[] battery_power_d = new double[96];//��طŵ�
	private double[] battery_power_c = new double[96];//��س��
	private double[] gd_power = new double[96];
	
	//��init���ݿ��ж�ȡ
	private double[] pv_power = new double[96];
	private double[] wind_power = new double[96];
	private double[] load = new double[96];
	private double[] loadThree = new double[96];
	//��init����
	double[] need_load = new double[96];
	double[] need_load_person = new double[96];
	private double tempCost;

	private void init(LocalDate day)
	{
		PowerConsumtion PC = new PowerConsumtion();
		WindPower WP = new WindPower();
		PV Solar = new PV();
		//GasPower GS = new GasPower();

		//LocalDate day = LocalDate.parse("2017-07-01");
		System.out.println(day);

		load = PC.getDayData(day);
		loadThree = PC.getDayDataThree(day);
		wind_power = WP.getDayData(day);
		pv_power = Solar.getDayDate(day);
		//gas_power = GS.getDayData(day);//ȼ�����粻�����ݿ�������

		for (int i = 0; i < 96; i++)
		{
			need_load[i] = load[i] - wind_power[i] - pv_power[i];
			need_load_person[i] = loadThree[i] - wind_power[i] - pv_power[i];
		}
		
		for (int i = 0; i < 96; i++)
		{
			tempCost += need_load[i]*0.2;
		}
		
		BG_SOCP testSocp = new BG_SOCP(day);
		
		gas_power = testSocp.getDayDate_Gas();
		battery_power_d = testSocp.getDayDate_BatteryD();
		battery_power_c = testSocp.getDayDate_BatteryC();
		gd_power = testSocp.getDayDate_Grid();
	}
	
	public double[][] out(LocalDate day) {
		
		double[][] result = new double[8][96];
		init(day);
		
		result[0] = load;
		result[1] = loadThree;
		result[2] = wind_power;
		result[3] = pv_power;
		result[4] = gas_power;
		for(int i = 0; i < 96; i++) {
			result[5][i] = battery_power_d[i] + battery_power_c[i];
		}
		result[6] = need_load;
		result[7] = need_load_person;
		return result;
	}
	
	private void test_out()
	{
		System.out.println();
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println("Index" + "\t" + "����" + "\t" + "-���" + "\t" + "-���" + "\t" + "=����="
				+ "\t" + "+���d" + "\t" + "+���c" + "\t" + "+ȼ��" + "\t" + "+����");
		for (int i = 0; i < 96; i++)
		{
			System.out.println(i + "\t" + load[i] + "\t" + pv_power[i] + "\t" + wind_power[i]
					+ "\t" + df.format(need_load[i]) + "\t" + df.format(battery_power_d[i]) 
					 + "\t" + df.format(battery_power_c[i])
					+ "\t" + gas_power[i] + "\t" + gd_power[i]);
		}
		
		System.out.println(tempCost);

	}

	public static void main(String[] args)
	{	
		LocalDate day = LocalDate.parse("2017-03-02");
		
		MGO_Test thisTest = new MGO_Test();
		thisTest.init(day);
		
		thisTest.test_out();
		

	}
	
	
}
