package com.usst.ee;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.*;

import com.usst.edu.JdbcUtils.JdbcUtils;

import david.PSO.*;

//封装的能效评级类-简单封装-MYSQL相关数据准备
//暂时为了同一group_id不重复优化参数，未来在此基础上改成EE工厂类
public class EE
{
	private static int group_id;
	private static final EE aEE = new EE();//保证此类对象只能创建一个
	private int test_id;
	
	
	private double[][] trainIn = new double[50][10];
	private double[] trainOut = new double[50];
	
	private double[] trainRstMin = new double[10];
	private double[] trainRstMax = new double[10];
	
	private double[][] normValue = new double[10][2];	
	private double[] EEGlobalBestX = new double[10];

	
	private String mysql_driver;
	private String mysql_url;
	private String mysql_user;
	private String mysql_pass;
	
	public int[] error = new int[10];
	
	private void initDBParam(){
		// 使用Properties类来加载属性文件
		Properties props = new Properties();
		try{
			props.load(new FileInputStream("C:/Users/WORK01/Desktop/nx/MVC_1/src/mysql.ini"));
		}catch (Exception e){
			e.printStackTrace();
		}
		mysql_driver = props.getProperty("driver");
		mysql_url = props.getProperty("url");
		mysql_user = props.getProperty("user");
		mysql_pass = props.getProperty("pass");
	}
	
	//构造1，传入能效评级区域区域group_id
	private EE()
	{
		
	}
	
	private void setGroupId(int input_group_id)
	{
		group_id = input_group_id;
		
		test_id = input_group_id;
		System.out.println("调用一次");
	}
	
	private void setTrainData(){//应当和group_id对应，先不考虑
		
		Connection mysql_conn = null;
		PreparedStatement selectST = null;
		ResultSet rs = null;
		
		try{
			mysql_conn = JdbcUtils.getConnection();
			selectST = mysql_conn.prepareStatement("select * from ee_train_data order by EE_TRAIN_INDEX");
			rs = selectST.executeQuery();	
			int i = 0;
			while (rs.next()){
				for (int j = 2; j < 12; j++){
					trainIn[i][j-2] = rs.getDouble(j);
				}	
				trainOut[i] = rs.getDouble(12);
				i++;
			}
		}catch (Exception e){
			JdbcUtils.releaseConnection(mysql_conn, selectST, rs);
		}
	}
	
	private void setNormData()//应当和group_id对应，先不考虑
	{
		Connection mysql_conn = null;
		PreparedStatement selectST = null;
		ResultSet rs = null;
		
		try{
			mysql_conn = JdbcUtils.getConnection();
				// 创建JdbcRowSetImpl对象
			selectST = mysql_conn.prepareStatement("SELECT * FROM ee_normalization order by DATA_TYPE");
		
			rs = selectST.executeQuery();
			
			int i = 0;
			while (rs.next()){
				normValue[i][0] = rs.getDouble(2);
				normValue[i][1] = rs.getDouble(3);	
				i++;	
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(mysql_conn, selectST, rs);
		}
		
		System.out.println(Arrays.toString(normValue));
		
	}
	
	
	private void EESearch()
	{
		PSO pso = new PSO(10, 30);
		
		pso.setData(trainIn, trainOut);
		
		pso.Initialize();
		
		
		
		pso.Search();
		
		double[] PSOGlobalBestX ;//= new double[9];
		
		//System.out.println();
		
		PSOGlobalBestX = pso.getGlobalBestX();
		
		//测试输出
		for (int i = 0; i < PSOGlobalBestX.length; i++)
		{
			//System.out.print(PSOGlobalBestX[i] + " ");
			EEGlobalBestX[i] = PSOGlobalBestX[i];
		}
		System.out.println();
		
		
		/*double sum1;
		double[] z = new double[10];
		double[] w = new double[50];
		for (int j = 0; j < 50; j++)
		{
			sum1 = 0;
			for (int i = 0; i < 10; i++)
			{
				z[i] = globalBestX[i]*trainIn[j][i];
				sum1 += z[i];
			}
			w[j] = sum1;
			//System.out.print(w[j] + " ");
			
		}*/
		
		//50个样本带入最优系数求解
		double[] trainRst = new double[50];
		
		for (int i = 0; i < trainRst.length; i++) 
		{
			trainRst[i] = 0;
			for (int j = 0; j < PSOGlobalBestX.length; j++) 
			{
				trainRst[i] += PSOGlobalBestX[j] * trainIn[i][j];	
			}
			
		}
		
		
		//10分级的边界值
		double[] tempRstMin = new double[10];
		double[] tempRstMax = new double[10];
		for (int i = 0; i < 10; i++) 
		{
			tempRstMin[i] = 10000;
			for (int j = 0; j < 5; j++) 
			{
				if (trainRst[i*5 + j] > tempRstMax[i])
					tempRstMax[i] = trainRst[i*5 + j];
				if (trainRst[i*5 + j] < tempRstMin[i]) 
					tempRstMin[i] = trainRst[i*5 + j];
			}
			trainRstMax[i] = tempRstMax[i];
			trainRstMin[i] = tempRstMin[i];
		}
		
		for (int i = 0; i < 10; i++)
		{
			System.out.println(tempRstMin[i] + " " +  tempRstMax[i]);
		}
	}
	//构造2，默认无参数构造
	public static EE getEE(int input_group_id){
		
		System.out.println("123456...");
		
		if (input_group_id != group_id){
			aEE.setGroupId(input_group_id);
			aEE.initDBParam();
			aEE.setTrainData();
			aEE.setNormData();
			aEE.EESearch();
		}
		return aEE;
	}
	
	//设定评级区域

	
	//准备数据1优化数据，2评价输入
	
	public String testoutput()
	{
		return String.valueOf(group_id);
	}
	public String testoutput1()
	{
		return String.valueOf(test_id);
	}
	//优化函数
	
	
	//返回评价值
	public double getEEDegree(double[] input)
	{
		//输入归一化
		double[] normInput = new double[10];
		double tempRst;

		for (int i = 0; i < 10; i++)
		{

			normInput[i] = (input[i] - normValue[i][0])/(normValue[i][1] - normValue[i][0]);
			if (normInput[i]<0 || normInput[i]>1)
				error[i] = 1;
				//return -301-i;//输入越界
			else
				error[i] = 0;		
		}

		tempRst = 0;
		for (int i = 0; i < EEGlobalBestX.length; i++) 
		{
			tempRst += EEGlobalBestX[i]*normInput[i];
		}

		//开始评级
		int j = 0;
		for (j = 1; j <= 10; j++)
		{
			if (tempRst > trainRstMin[j-1])
				break;
		}
		
		if(tempRst > trainRstMax[0] || tempRst < trainRstMin[9]){
			return 1;
		}
		
		double rst = j;
		
		System.out.println(tempRst);
		//落在间隙点a
		if(tempRst > trainRstMax[j-1])
		{
			rst -= 1;
			
			//rst += (tempRst - trainRstMax[i-1])/(trainRstMin[i-2] - trainRstMax[i-1]);
			rst += (trainRstMin[j-2] - tempRst)/(trainRstMin[j-2] - trainRstMax[j-1]);///此处调整
			
		}
		
		return rst;
	}
}
