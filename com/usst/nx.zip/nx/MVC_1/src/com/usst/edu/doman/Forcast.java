package com.usst.edu.doman;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;

public class Forcast {
	private int CITY_ID;
	private Timestamp DATA_DATE;
	private int GROUP_ID;
	private int EC_DATA_TYPE;
	private int EC_DATA_POINT;
	private double [] EC_ENERGY = new double[96];
	public int getCITY_ID() {
		return CITY_ID;
	}
	public void setCITY_ID(int cITY_ID) {
		CITY_ID = cITY_ID;
	}
	public Timestamp getDATA_DATE() {
		return DATA_DATE;
	}
	public void setDATA_DATE(Timestamp dATA_DATE) {
		DATA_DATE = dATA_DATE;
	}
	public int getGROUP_ID() {
		return GROUP_ID;
	}
	public void setGROUP_ID(int gROUP_ID) {
		GROUP_ID = gROUP_ID;
	}
	public int getEC_DATA_TYPE() {
		return EC_DATA_TYPE;
	}
	public void setEC_DATA_TYPE(int eC_DATA_TYPE) {
		EC_DATA_TYPE = eC_DATA_TYPE;
	}
	public int getEC_DATA_POINT() {
		return EC_DATA_POINT;
	}
	public void setEC_DATA_POINT(int eC_DATA_POINT) {
		EC_DATA_POINT = eC_DATA_POINT;
	}
	public double[] getEC_ENERGY() {
		return EC_ENERGY;
	}
	public void setEC_ENERGY(double[] eC_ENERGY) {
		EC_ENERGY = eC_ENERGY;
	}
	@Override
	public String toString() {
		return "Forcast [CITY_ID=" + CITY_ID + ", DATA_DATE=" + DATA_DATE + ", GROUP_ID=" + GROUP_ID + ", EC_DATA_TYPE="
				+ EC_DATA_TYPE + ", EC_DATA_POINT=" + EC_DATA_POINT + ", EC_ENERGY=" + Arrays.toString(EC_ENERGY) + "]";
	}
	public Forcast(int cITY_ID, Timestamp dATA_DATE, int gROUP_ID, int eC_DATA_TYPE, int eC_DATA_POINT, double[] eC_ENERGY) {
		super();
		CITY_ID = cITY_ID;
		DATA_DATE = dATA_DATE;
		GROUP_ID = gROUP_ID;
		EC_DATA_TYPE = eC_DATA_TYPE;
		EC_DATA_POINT = eC_DATA_POINT;
		EC_ENERGY = eC_ENERGY;
	}
	public Forcast() {
		super();
	}
	
}
