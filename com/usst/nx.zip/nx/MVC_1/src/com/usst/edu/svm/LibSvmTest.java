package com.usst.edu.svm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.sun.swing.internal.plaf.basic.resources.basic_zh_TW;

import libsvm.svm;
import libsvm.*;

public class LibSvmTest {
	
	public static List<double[]> scaleTrain(){
		File file = new File("C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\train.txt");
		List<double[]> list = null;
		FileWriter fw;
		BufferedWriter bw;
		try {
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
			String[] testArgsGY = {"-l","0", "-u","1","-y","0","1","-s","C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\chao-train-scale","C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\train1.txt"};
			list =  svm_scale1.main(testArgsGY,bw);
	        fw.close();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public static List<double[]> scaleTest(){
		File file = new File("C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\test\\test.txt");
		List<double[]> list = null;
		FileWriter fw;
		BufferedWriter bw;
		try {
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
	        String[] argvScaleTest ={"-l","0", "-u","1","-y","0","1","-s","C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\test\\chao-test-scale","C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\test\\test1.txt"};
	        list = svm_scale1.main(argvScaleTest,bw);
	        fw.close();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 return list;
	}
	
    public static void main(String[] args) throws IOException {
    	List<double[]> list = null;
    	list = scaleTrain();
    	
    	list.forEach(i -> {
    		System.out.println("train >> " + Arrays.toString(i));
    	});
    	
    	list = scaleTest();
    	
    	list.forEach(j -> {
    		System.out.println("test >> " + Arrays.toString(j));
    	});
    	
    	double max = list.get(0)[0];
    	double min = list.get(1)[0];
        
        String[] trainArgs = {"-c","88","-s","4","-t","0","C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\train.txt", "C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\model.txt"};

        String[] testArgs = {"C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\test\\test.txt", "C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\train\\model.txt", "C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\result\\out.txt"};

        svm_train t = new svm_train();

        svm_predict p= new svm_predict();

        t.main(trainArgs);   //调用

        p.main(testArgs);  //调用
        System.out.println();
        
    	File file = new File("C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\result\\out.txt");
    	FileReader fw = new FileReader(file);
		BufferedReader bw = new BufferedReader(fw);

		File file1 = new File("C:\\Users\\Hu\\Desktop\\MVC_1\\WebContent\\result\\out1.txt");
		FileWriter fw1 = new FileWriter(file1);
		BufferedWriter bw1 = new BufferedWriter(fw1);
		String line = null;
		double data = 0;
		while((line = bw.readLine()) != null) {
			data = Double.parseDouble(line);
			data = rescale(max, min, data);
			System.out.println(max);
			System.out.println(min);
			System.out.println(line + " >> " + data);
			line = String.valueOf(data);
			bw1.write(line + "\r\n");
		}
		bw.close();
		fw.close();
		bw1.close();
		fw1.close();
    }
    
    public static double rescale(double max,double min,double target) {
    	target = target * (max - min) + min;
    	return target;
    }
}
