package com.usst.edu.youhua;

import java.time.LocalDate;

import gurobi.GRB;
import gurobi.GRBEnv;
import gurobi.GRBException;
import gurobi.GRBLinExpr;
import gurobi.GRBModel;
import gurobi.GRBVar;

public class BG_SOCP
{
	// �Ż����
	private double[] gas_power = new double[96];
	private double[] battery_d = new double[96];
	private double[] battery_c = new double[96];
	private double[] gd_power = new double[96];

	// ��init���ݿ��ж�ȡ
	private double[] pv_power = new double[96];
	private double[] wind_power = new double[96];
	private double[] load = new double[96];
	// ��init����
	double[] need_load = new double[96];

	private double totalCost;

	private void init(LocalDate day)
	{
		PowerConsumtion PC = new PowerConsumtion();
		WindPower WP = new WindPower();
		PV Solar = new PV();
		// GasPower GS = new GasPower();

		// LocalDate day = LocalDate.parse("2017-07-01");
		System.out.println(day);

		load = PC.getDayData(day);
		wind_power = WP.getDayData(day);
		pv_power = Solar.getDayDate(day);
		// gas_power = GS.getDayData(day);//ȼ�����粻�����ݿ�������

		for (int i = 0; i < 96; i++)
		{
			need_load[i] = load[i] - wind_power[i] - pv_power[i];
		}
	}
	
	public BG_SOCP(LocalDate day)
	{
		init(day);
		SOCP();
	}

	private void SOCP()
	{
		try
		{
			double dt = 0.25;
			// System.out.println(dt);
			int n = 96;

			double new_batter_soc = 0.5; // ��س�ʼsoc״̬

			double battery_soc_l = 0.3; // ����soc��Сֵ
			double battery_soc_h = 0.8; // ����soc���ֵ
			double battery_power_c = -15; // ���ܳ�繦�����ֵ��kw
			double battery_power_d = 25; // ���ܷŵ繦�����ֵ,kw
			double Q = 50.0; // ��������

			double gs_power_h = 500;// ȼ����������������

			// Model
			GRBEnv env = new GRBEnv();
			GRBModel model = new GRBModel(env);
			model.set(GRB.StringAttr.ModelName, "battery");

			// Add variables to the model
			GRBVar[] battery_soc = new GRBVar[n + 1];// ��ص�soc״̬
			battery_soc[0] = model.addVar(new_batter_soc, new_batter_soc, 0, GRB.CONTINUOUS, "battery_soc_0");
			for (int i = 1; i < n; ++i)
			{
				battery_soc[i] = model.addVar(battery_soc_l, battery_soc_h, 0, GRB.CONTINUOUS, "battery_soc_" + i);
			}
			battery_soc[n] = model.addVar(new_batter_soc, new_batter_soc, 0, GRB.CONTINUOUS, "battery_soc_96");

			GRBVar[] battery_d_power = new GRBVar[n];// ��طŵ�״̬
			for (int i = 0; i < n; ++i)
			{
				battery_d_power[i] = model.addVar(0, battery_power_d, 0, GRB.CONTINUOUS, "battery_d_power_" + i);
			}

			GRBVar[] battery_c_power = new GRBVar[n];// ��س��״̬
			for (int i = 0; i < n; ++i)
			{
				battery_c_power[i] = model.addVar(battery_power_c, 0, 0, GRB.CONTINUOUS, "battery_c_power_" + i);
			}

			GRBVar[] gs_d_power = new GRBVar[n];// ȼ���������
			for (int i = 0; i < n; ++i)
			{
				gs_d_power[i] = model.addVar(0, gs_power_h, 0, GRB.CONTINUOUS, "gs_power_" + i);
			}

			GRBVar[] gd_d_power = new GRBVar[n];// ��������
			for (int i = 0; i < n; ++i)
			{
				gd_d_power[i] = model.addVar(-1000, GRB.INFINITY, 0, GRB.CONTINUOUS, "gd_power_" + i);
			}
			// Populate constraint(A matrix)
			// ���soc״̬����
			for (int i = 0; i < n; ++i)
			{
				GRBLinExpr soc_next = new GRBLinExpr();

				soc_next.addTerm(1, battery_soc[i]);

				soc_next.addTerm(-1.111 * dt / Q, battery_d_power[i]);
				soc_next.addTerm(-0.9 * dt / Q, battery_c_power[i]);

				model.addConstr(battery_soc[i + 1], GRB.EQUAL, soc_next, "soc_next" + i);
			}
			// ����ƽ��
			for (int i = 0; i < n; ++i)
			{
				GRBLinExpr power_eq = new GRBLinExpr();
				power_eq.addTerm(1, gd_d_power[i]);
				power_eq.addTerm(1, gs_d_power[i]);
				power_eq.addTerm(1, battery_c_power[i]);
				power_eq.addTerm(1, battery_d_power[i]);
				model.addConstr(power_eq, GRB.EQUAL, need_load[i], "power_eq" + i);
			}

			// Ŀ�꺯�����򻯰汾2��test
			GRBLinExpr obj = new GRBLinExpr();
			for (int i = 0; i < n; ++i)
			{
				obj.addTerm(0.1, gd_d_power[i]);
				obj.addTerm(0.175, gs_d_power[i]);
				obj.addTerm(0.05, battery_d_power[i]);
			}
			for (int i = 32; i < 88; ++i)
			{
				obj.addTerm(0.1, gd_d_power[i]);
			}
			model.setObjective(obj);// The objective is to minimize the costs

			model.optimize();

			if (model.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL)
			{
				//DecimalFormat df = new DecimalFormat("0.0000");
				//System.out.println("\nTotal Cost: " + model.get(GRB.DoubleAttr.ObjVal));
				totalCost = model.get(GRB.DoubleAttr.ObjVal);
				//System.out.println("\n\tSoc:\td_power\tc_power");
				for (int i = 0; i < 96; ++i)
				{
					//System.out.print(i + "\t" + df.format(battery_soc[i].get(GRB.DoubleAttr.X)));
					//System.out.print("\t" + df.format(battery_d_power[i].get(GRB.DoubleAttr.X)));
					//System.out.print("\t " + df.format(battery_c_power[i].get(GRB.DoubleAttr.X)));
					battery_d[i] = battery_d_power[i].get(GRB.DoubleAttr.X);
					battery_c[i] = battery_c_power[i].get(GRB.DoubleAttr.X);
					//System.out.print("\t" + df.format(need_load[i]));
					//System.out.print("\t" + df.format(gs_d_power[i].get(GRB.DoubleAttr.X)));
					gas_power[i] = gs_d_power[i].get(GRB.DoubleAttr.X);
					//System.out.println("\t " + df.format(gd_d_power[i].get(GRB.DoubleAttr.X)));
					gd_power[i] = gd_d_power[i].get(GRB.DoubleAttr.X);
				}
				//System.out.print(96 + "\t" + df.format(battery_soc[96].get(GRB.DoubleAttr.X)));
			}
			else
			{
				System.out.println("No solution");
				totalCost = -999;
			}

			// Dispose of model and environment
			model.dispose();
			env.dispose();
		}
		catch (GRBException e)
		{
			System.out.println("Error code: " + e.getErrorCode() + ". " + e.getMessage());
		}
	}
	
	public double[] getDayDate_Grid()
	{
		return gd_power;
	}
	
	public double[] getDayDate_BatteryD()
	{
		return battery_d;
	}
	public double[] getDayDate_BatteryC()
	{
		return battery_c;
	}
	
	public double[] getDayDate_Gas()
	{
		return gas_power;
	}
	
	public double getDayTotalCost()
	{
		return totalCost;
	}
}
