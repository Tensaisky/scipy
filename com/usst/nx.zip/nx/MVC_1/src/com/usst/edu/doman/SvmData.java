package com.usst.edu.doman;

public class SvmData {
	
	private double L7t = 0;
	private double L7ave = 0;
	private boolean D7 = false;
	private double L1t_1 = 0;
	private double L1t = 0;
	private double L1t1 = 0;
	private double L1ave = 0;
	private boolean D1 = false;
	private boolean D = false;
	private double Lt = 0;
	public double getL7t() {
		return L7t;
	}
	public void setL7t(double l7t) {
		L7t = l7t;
	}
	public double getL7ave() {
		return L7ave;
	}
	public void setL7ave(double l7ave) {
		L7ave = l7ave;
	}
	public boolean isD7() {
		return D7;
	}
	public void setD7(boolean d7) {
		D7 = d7;
	}
	public double getL1t_1() {
		return L1t_1;
	}
	public void setL1t_1(double l1t_1) {
		L1t_1 = l1t_1;
	}
	public double getL1t() {
		return L1t;
	}
	public void setL1t(double l1t) {
		L1t = l1t;
	}
	public double getL1t1() {
		return L1t1;
	}
	public void setL1t1(double l1t1) {
		L1t1 = l1t1;
	}
	public double getL1ave() {
		return L1ave;
	}
	public void setL1ave(double l1ave) {
		L1ave = l1ave;
	}
	public boolean isD1() {
		return D1;
	}
	public void setD1(boolean d1) {
		D1 = d1;
	}
	public boolean isD() {
		return D;
	}
	public void setD(boolean d) {
		D = d;
	}
	public double getLt() {
		return Lt;
	}
	public void setLt(double lt) {
		Lt = lt;
	}
	public SvmData(double l7t, double l7ave, boolean d7, double l1t_1, double l1t, double l1t1, double l1ave,
			boolean d1, boolean d, double lt) {
		super();
		L7t = l7t;
		L7ave = l7ave;
		D7 = d7;
		L1t_1 = l1t_1;
		L1t = l1t;
		L1t1 = l1t1;
		L1ave = l1ave;
		D1 = d1;
		D = d;
		Lt = lt;
	}
	public SvmData() {
		super();
	}
	@Override
	public String toString() {
		return "SvmData [L7t=" + L7t + ", L7ave=" + L7ave + ", D7=" + D7 + ", L1t_1=" + L1t_1 + ", L1t=" + L1t
				+ ", L1t1=" + L1t1 + ", L1ave=" + L1ave + ", D1=" + D1 + ", D=" + D + ", Lt=" + Lt + "]";
	}
	
}
