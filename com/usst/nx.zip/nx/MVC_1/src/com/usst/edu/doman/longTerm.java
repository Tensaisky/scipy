package com.usst.edu.doman;

public class longTerm {

	private boolean tSuType = false;
	private boolean tSaType = false;
	private boolean tStartType = false;
	private boolean tMidType = false;
	private boolean tLateType = false;
	private double todayMax = 0;
	
	private boolean fSuType = false;
	private boolean fSaType = false;
	private boolean fStartType = false;
	private boolean fMidType = false;
	private boolean fLateType = false;
	private double fiveWeekMax = 0;
	
	private boolean sSuType = false;
	private boolean sSaType = false;
	private boolean sStartType = false;
	private boolean sMidType = false;
	private boolean sLateType = false;
	private double sixWeekMax = 0;

	private boolean svSuType = false;
	private boolean svSaType = false;
	private boolean svStartType = false;
	private boolean svMidType = false;
	private boolean svLateType = false;
	private double sevenWeekMax = 0;
	
	private boolean eSuType = false;
	private boolean eSaType = false;
	private boolean eStartType = false;
	private boolean eMidType = false;
	private boolean eLateType = false;
	private double eightWeekMax = 0;
	public boolean istSuType() {
		return tSuType;
	}
	public void settSuType(boolean tSuType) {
		this.tSuType = tSuType;
	}
	public boolean istSaType() {
		return tSaType;
	}
	public void settSaType(boolean tSaType) {
		this.tSaType = tSaType;
	}
	public boolean istStartType() {
		return tStartType;
	}
	public void settStartType(boolean tStartType) {
		this.tStartType = tStartType;
	}
	public boolean istMidType() {
		return tMidType;
	}
	public void settMidType(boolean tMidType) {
		this.tMidType = tMidType;
	}
	public boolean istLateType() {
		return tLateType;
	}
	public void settLateType(boolean tLateType) {
		this.tLateType = tLateType;
	}
	public double getTodayMax() {
		return todayMax;
	}
	public void setTodayMax(double todayMax) {
		this.todayMax = todayMax;
	}
	public boolean isfSuType() {
		return fSuType;
	}
	public void setfSuType(boolean fSuType) {
		this.fSuType = fSuType;
	}
	public boolean isfSaType() {
		return fSaType;
	}
	public void setfSaType(boolean fSaType) {
		this.fSaType = fSaType;
	}
	public boolean isfStartType() {
		return fStartType;
	}
	public void setfStartType(boolean fStartType) {
		this.fStartType = fStartType;
	}
	public boolean isfMidType() {
		return fMidType;
	}
	public void setfMidType(boolean fMidType) {
		this.fMidType = fMidType;
	}
	public boolean isfLateType() {
		return fLateType;
	}
	public void setfLateType(boolean fLateType) {
		this.fLateType = fLateType;
	}
	public double getFiveWeekMax() {
		return fiveWeekMax;
	}
	public void setFiveWeekMax(double fiveWeekMax) {
		this.fiveWeekMax = fiveWeekMax;
	}
	public boolean issSuType() {
		return sSuType;
	}
	public void setsSuType(boolean sSuType) {
		this.sSuType = sSuType;
	}
	public boolean issSaType() {
		return sSaType;
	}
	public void setsSaType(boolean sSaType) {
		this.sSaType = sSaType;
	}
	public boolean issStartType() {
		return sStartType;
	}
	public void setsStartType(boolean sStartType) {
		this.sStartType = sStartType;
	}
	public boolean issMidType() {
		return sMidType;
	}
	public void setsMidType(boolean sMidType) {
		this.sMidType = sMidType;
	}
	public boolean issLateType() {
		return sLateType;
	}
	public void setsLateType(boolean sLateType) {
		this.sLateType = sLateType;
	}
	public double getSixWeekMax() {
		return sixWeekMax;
	}
	public void setSixWeekMax(double sixWeekMax) {
		this.sixWeekMax = sixWeekMax;
	}
	public boolean isSvSuType() {
		return svSuType;
	}
	public void setSvSuType(boolean svSuType) {
		this.svSuType = svSuType;
	}
	public boolean isSvSaType() {
		return svSaType;
	}
	public void setSvSaType(boolean svSaType) {
		this.svSaType = svSaType;
	}
	public boolean isSvStartType() {
		return svStartType;
	}
	public void setSvStartType(boolean svStartType) {
		this.svStartType = svStartType;
	}
	public boolean isSvMidType() {
		return svMidType;
	}
	public void setSvMidType(boolean svMidType) {
		this.svMidType = svMidType;
	}
	public boolean isSvLateType() {
		return svLateType;
	}
	public void setSvLateType(boolean svLateType) {
		this.svLateType = svLateType;
	}
	public double getSevenWeekMax() {
		return sevenWeekMax;
	}
	public void setSevenWeekMax(double sevenWeekMax) {
		this.sevenWeekMax = sevenWeekMax;
	}
	public boolean iseSuType() {
		return eSuType;
	}
	public void seteSuType(boolean eSuType) {
		this.eSuType = eSuType;
	}
	public boolean iseSaType() {
		return eSaType;
	}
	public void seteSaType(boolean eSaType) {
		this.eSaType = eSaType;
	}
	public boolean iseStartType() {
		return eStartType;
	}
	public void seteStartType(boolean eStartType) {
		this.eStartType = eStartType;
	}
	public boolean iseMidType() {
		return eMidType;
	}
	public void seteMidType(boolean eMidType) {
		this.eMidType = eMidType;
	}
	public boolean iseLateType() {
		return eLateType;
	}
	public void seteLateType(boolean eLateType) {
		this.eLateType = eLateType;
	}
	public double getEightWeekMax() {
		return eightWeekMax;
	}
	public void setEightWeekMax(double eightWeekMax) {
		this.eightWeekMax = eightWeekMax;
	}
	
}
