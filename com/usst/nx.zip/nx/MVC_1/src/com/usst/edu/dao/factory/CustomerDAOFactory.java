package com.usst.edu.dao.factory;

import java.util.HashMap;
import java.util.Map;

import com.usst.edu.dao.CustomerDAO;
import com.usst.edu.dao.impl.CustomerDAOJdbcImpl;

public class CustomerDAOFactory {
	
	private Map<String, CustomerDAO> daos=new HashMap<String,CustomerDAO>();
	private String type=null;
	
	private CustomerDAOFactory(){
		daos.put("jdbc", new CustomerDAOJdbcImpl());
		
	}
	private static CustomerDAOFactory instance=new CustomerDAOFactory();
	
	public static CustomerDAOFactory getInstance(){
		return instance;
	}
	
	public void setType(String type){
		this.type=type;
	}
	
	public CustomerDAO getCustomerDAO(){
		return daos.get(type);
	}
	
}
