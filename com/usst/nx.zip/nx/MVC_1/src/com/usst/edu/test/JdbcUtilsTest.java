package com.usst.edu.test;

import static org.hamcrest.CoreMatchers.describedAs;
import static org.junit.Assert.*;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.junit.Before;
import org.junit.Test;

import com.sun.xml.internal.ws.message.DataHandlerAttachment;
import com.usst.edu.JdbcUtils.JdbcUtils;
import com.usst.edu.doman.SvmData;
import com.usst.edu.svm.LibSvmTest;

import javafx.util.converter.LocalDateStringConverter;
import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import libsvm.svm_parameter;
import libsvm.svm_problem;
public class JdbcUtilsTest {
	
	private QueryRunner queryRunner=new QueryRunner();

	@Test
	public void testGetConnection() throws SQLException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String sql = null;
		LocalDate date = LocalDate.of(2013, 10, 1);
		boolean flag = false;
		try{
			connection = JdbcUtils.getConnection();
			for(int i = 0; i < 31; i++){
				if(isWeekends(date))
					flag = true;
				else
					flag = false;
				System.out.println(date + ">> " + flag);
				sql = "UPDATE ec_d_power_curve SET DayType = " + flag + " WHERE  DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
				queryRunner.update(connection, sql);
				date = date.plusDays(1);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(connection);
		}
		
	}
	
	@Test
	public void test3(){
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String sql = null;
		String sqlave = null;
		double[] data = new double[288];
		LocalDate date = LocalDate.of(2013, 10, 1);
		double sum = 0;
		double ave = 0;
		try {
			connection = JdbcUtils.getConnection();
			sql = "SELECT * FROM ec_d_power_curve";
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				for(int i = 0; i < 288; i++){
					sum += resultSet.getDouble(i+3);
				}
				ave = sum / 288;
				sqlave = "UPDATE ec_d_power_curve SET average = " + ave + " WHERE  DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
				queryRunner.update(connection, sqlave);
				date = date.plusDays(1);
				sum = 0;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(connection);
		}
	}
	
	@Test
	public void test(){
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement statement2 = null;
		ResultSet resultSet = null;
		String sql = null;
		String sqlave = null;
		LocalDate date = LocalDate.of(2012, 1, 1);
		double[] data = new double[24];
		boolean flag = false;
		try {
			connection = JdbcUtils.getConnection();
			sql = "SELECT * FROM ec_d_power_curve_chuanjiang";
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				flag = resultSet.getBoolean(2);
				for(int i = 0; i < 24; i++){
					data[i] = resultSet.getDouble(i * 12 + 4);
				}
				//getAverage(data);
				System.out.println(flag + ">> " + Arrays.toString(data));
				sqlave = getSQL(date, flag, data);
				queryRunner.update(connection,sqlave);
				date = date.plusDays(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean isWeekends(LocalDate date){
		if((date.getDayOfWeek() == DayOfWeek.SATURDAY) || (date.getDayOfWeek() == DayOfWeek.SUNDAY))
			return true;
		else
			return false;
	}
	
	public String getSQL(LocalDate date, boolean b, double[] data){
		StringBuilder sb = new StringBuilder("INSERT INTO ec_d_power_curve_average24_chuanjiang (DATA_DATE,DayType,average,");
		double sum = 0;
		for(int i = 1; i < 24; i++) {
			sb.append("EC_ENERGY_" + i + ",");
			sum += data[i-1];
		}
		sum += data[23];
		double ave = sum / 24;
		sb.append("EC_ENERGY_24) VALUES ( STR_TO_DATE('" + date + "', '%Y-%m-%d')," + b + "," + ave + ",");
		for(int i = 0; i < 23; i++) {
			sb.append(data[i] + ",");
		}
		sb.append(data[23] + ")");
		String sql = sb.toString();
		//System.out.println(sql);
		return sql;
	}
	
	public void getAverage(double[] data) {
		double max = 0;
		double min = 0;
		for(int i = 0; i < data.length; i++) {
			if(data[i] > max)
				max = data[i];
			if(data[i] < min)
				min = data[i];
		}
		double maxmin = max - min;
		for(int i = 0; i < data.length; i++) {
			data[i] = 0.1 + 0.8 * (data[i] - min)/maxmin;
		}
	}
	

	public double[] write(int day){
		
		LocalDate date = LocalDate.of(2012, 6, 1);

		SvmData[][] svmDatas = new SvmData[24][30];
		double[][] max = new double[24][7];
		double[][] min = new double[24][7];
		
		for(int i = 0; i < 30; i++) {
			for(int j = 1; j < 25; j++){
				SvmData svmData = new SvmData();
				getSql(date, j, svmData);
				svmDatas[j-1][i] = svmData;
			}
			date = date.plusDays(1);
		}
		
		max = getMax(svmDatas);
		min = getMin(svmDatas);
		
		for(int i = 0; i < 24; i++) {
			for (int j = 0; j < 30; j++) {
				retreat(svmDatas[i][j], max[i], min[i]);
			}
		}
		
		svm_node[][][] datas = new svm_node[24][30][9];
		double[][] labels = new double[24][30];
		for(int i = 0; i < 24; i++) {
			for(int j = 0; j < 30; j++) {
				
				labels[i][j] = svmDatas[i][j].getLt();
				
				datas[i][j][0] = new svm_node();
				datas[i][j][0].index = 0;
				datas[i][j][0].value = (svmDatas[i][j].isD() == true ? 1 : 0);
				
				datas[i][j][1] = new svm_node();
				datas[i][j][1].index = 1;
				datas[i][j][1].value = (svmDatas[i][j].isD1() == true ? 1 : 0);
				
				datas[i][j][2] = new svm_node();
				datas[i][j][2].index = 2;
				datas[i][j][2].value = svmDatas[i][j].getL1ave();
				
				datas[i][j][3] = new svm_node();
				datas[i][j][3].index = 3;
				datas[i][j][3].value = svmDatas[i][j].getL1t_1();
				
				datas[i][j][4] = new svm_node();
				datas[i][j][4].index = 4;
				datas[i][j][4].value = svmDatas[i][j].getL1t();
				
				datas[i][j][5] = new svm_node();
				datas[i][j][5].index = 5;
				datas[i][j][5].value = svmDatas[i][j].getL1t1();
				
				datas[i][j][6] = new svm_node();
				datas[i][j][6].index = 6;
				datas[i][j][6].value = (svmDatas[i][j].isD7() == true ? 1 : 0);
				
				datas[i][j][7] = new svm_node();
				datas[i][j][7].index = 7;
				datas[i][j][7].value = svmDatas[i][j].getL7ave();
				
				datas[i][j][8] = new svm_node();
				datas[i][j][8].index = -1;
				datas[i][j][8].value = svmDatas[i][j].getL7t();
			}
		}
		
		svm_model[] models = new svm_model[24];
		
        svm_parameter param = new svm_parameter();
        param.svm_type = svm_parameter.NU_SVR;
        param.kernel_type = svm_parameter.LINEAR;
        param.C = 88;
        param.cache_size = 100;
        param.eps = 1e-3;
        param.nu = 0.5;
        param.degree = 3;
		param.gamma = 0;	// 1/num_features
		param.coef0 = 0;
		param.p = 0.1;
		param.shrinking = 1;
		param.probability = 0;
		param.nr_weight = 0;
		
		for(int i = 0; i < 24; i++) {
			svm_problem problem = new svm_problem();
			problem.l = 30;
			problem.x = datas[i];
			problem.y = labels[i];
	        
	        //System.out.println(svm.svm_check_parameter(problem, param));
	        models[i] = svm.svm_train(problem, param);
		}
		
		double[] result = new double[24];
		for(int i = 0; i < 24; i++) {
			svm_node node0 = new svm_node();
			node0.index = 0;
			node0.value = (svmDatas[i][day].isD() == true ? 1 : 0);
			
			svm_node node1 = new svm_node();
			node1.index = 1;
			node1.value =  (svmDatas[i][day].isD1() == true ? 1 : 0);
			
			svm_node node2 = new svm_node();
			node2.index = 2;
			node2.value = svmDatas[i][day].getL1ave();
			
			svm_node node3 = new svm_node();
			node3.index = 3;
			node3.value = svmDatas[i][day].getL1t_1();
			
			svm_node node4 = new svm_node();
			node4.index = 4;
			node4.value =  svmDatas[i][day].getL1t();
			
			svm_node node5 = new svm_node();
			node5.index = 5;
			node5.value = svmDatas[i][day].getL1t1();
			
			svm_node node6 = new svm_node();
			node6.index = 6;
			node6.value = (svmDatas[i][day].isD7() == true ? 1 : 0);
			
			svm_node node7 = new svm_node();
			node7.index = 7;
			node7.value = svmDatas[i][day].getL7ave();
			svm_node node8 = new svm_node();
			node8.index = -1;
			node8.value = svmDatas[i][day].getL7t();
			
			svm_node[] pc = {node0,node1,node2,node3,node4,node5,node6,node7,node8};
			result[i] = svm.svm_predict(models[i], pc);
			result[i] = LibSvmTest.rescale(max[i][0], min[i][0], result[i]);
			
			result[i] = (int)(result[i] * 100)/100.0;
		}
		
//		for (int i = 0; i < 24; i++) {
//			System.out.println(result[i]);
//		}
		
		return result;
//		for (int i = 0; i < 24; i++) {
//			System.out.println(Arrays.toString(svmDatas[i]));
//		}
		
	}
	
	public void retreat(SvmData svmData, double[] max, double[] min) {
		
		if(svmData.getLt() == min[0]){
			svmData.setLt(0);
		}else if(svmData.getLt() == max[0]) {
			svmData.setLt(1);
		}else{
			svmData.setLt((svmData.getLt() - min[0])/(max[0] - min[0]));
		}
		
		if(svmData.getLt() == min[1]){
			svmData.setL1ave(0);
		}else if(svmData.getLt() == max[1]) {
			svmData.setL1ave(1);
		}else{
			svmData.setL1ave((svmData.getL1ave() - min[1])/(max[1] - min[1]));
		}
		
		if(svmData.getLt() == min[2]){
			svmData.setL1t_1(0);
		}else if(svmData.getLt() == max[2]) {
			svmData.setL1t_1(1);
		}else{
			svmData.setL1t_1((svmData.getL1t_1() - min[2])/(max[2] - min[2]));
		}
		
		if(svmData.getLt() == min[3]){
			svmData.setL1t(0);
		}else if(svmData.getLt() == max[3]) {
			svmData.setL1t(1);
		}else{
			svmData.setL1t((svmData.getL1t() - min[3])/(max[3] - min[3]));
		}
		
		if(svmData.getLt() == min[4]){
			svmData.setL1t1(0);
		}else if(svmData.getLt() == max[4]) {
			svmData.setL1t1(1);
		}else{
			svmData.setL1t1((svmData.getL1t1() - min[4])/(max[4] - min[4]));
		}
		
		if(svmData.getLt() == min[5]){
			svmData.setL7ave(0);
		}else if(svmData.getLt() == max[5]) {
			svmData.setL7ave(1);
		}else{
			svmData.setL7ave((svmData.getL7ave() - min[5])/(max[5] - min[5]));
		}
		
		if(svmData.getLt() == min[6]){
			svmData.setL7t(0);
		}else if(svmData.getLt() == max[6]) {
			svmData.setL7t(1);
		}else{
			svmData.setL7t((svmData.getL7t() - min[6])/(max[6] - min[6]));
		}
		
	}
	
	public double[][] getMax(SvmData[][] svmData) {
		double[][] label = new double[24][30];
		double[][] feature3 = new double[24][30];
		double[][] feature4 = new double[24][30];
		double[][] feature5 = new double[24][30];
		double[][] feature6 = new double[24][30];
		double[][] feature8 = new double[24][30];
		double[][] feature9 = new double[24][30];
		
		double[][] res = new double[24][7];
		
		for(int i = 0; i < 24; i++) {
				for(int k = 0; k < 30; k++) {
					label[i][k] = svmData[i][k].getLt();
				}
				res[i][0] = max(label[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature3[i][k] = svmData[i][k].getL1ave();
			}
			res[i][1] = max(feature3[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature4[i][k] = svmData[i][k].getL1t_1();
			}
			res[i][2] = max(feature4[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature5[i][k] = svmData[i][k].getL1t();
			}
			res[i][3] = max(feature5[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature6[i][k] = svmData[i][k].getL1t1();
			}
			res[i][4] = max(feature6[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature8[i][k] = svmData[i][k].getL7ave();
			}
			res[i][5] = max(feature3[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature9[i][k] = svmData[i][k].getL7t();
			}
			res[i][6] = max(feature9[i]);
		}
		
		return res;
	}
	
	public double max(double[] data) {
		double max = 0;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] > max) {
				max = data[i];
			}
		}
		
		return max;
	}
	
	public double[][] getMin(SvmData[][] svmData) {
		double[][] label = new double[24][30];
		double[][] feature3 = new double[24][30];
		double[][] feature4 = new double[24][30];
		double[][] feature5 = new double[24][30];
		double[][] feature6 = new double[24][30];
		double[][] feature8 = new double[24][30];
		double[][] feature9 = new double[24][30];
		
		double[][] res = new double[24][7];
		
		for(int i = 0; i < 24; i++) {
				for(int k = 0; k < 30; k++) {
					label[i][k] = svmData[i][k].getLt();
				}
				res[i][0] = min(label[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature3[i][k] = svmData[i][k].getL1ave();
			}
			res[i][1] = min(feature3[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature4[i][k] = svmData[i][k].getL1t_1();
			}
			res[i][2] = min(feature4[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature5[i][k] = svmData[i][k].getL1t();
			}
			res[i][3] = min(feature5[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature6[i][k] = svmData[i][k].getL1t1();
			}
			res[i][4] = min(feature6[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature8[i][k] = svmData[i][k].getL7ave();
			}
			res[i][5] = min(feature8[i]);
		}
		
		for(int i = 0; i < 24; i++) {
			for(int k = 0; k < 30; k++) {
				feature9[i][k] = svmData[i][k].getL7t();
			}
			res[i][6] = min(feature9[i]);
		}
		
		return res;
	}
	
	public double min(double[] data) {
		double min = 999999;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i] < min) {
				min = data[i];
			}
		}
		
		return min;
	}
	
	private void write(BufferedWriter bw, List<SvmData> list) throws IOException {
		SvmData sd;
		for(int i = 0; i < list.size(); i++){
			sd = list.get(i);
			bw.write(sd.getLt() + "\t");
			bw.write("1:" + (sd.isD()==true?1:0) + "\t");
			bw.write("2:" + (sd.isD1()==true?1:0) + "\t");
			bw.write("3:" + sd.getL1ave() + "\t");
			bw.write("4:" + sd.getL1t_1() + "\t");
			bw.write("5:" + sd.getL1t() + "\t");
			bw.write("6:" + sd.getL1t1() + "\t");
			bw.write("7:" + (sd.isD7()==true?1:0) + "\t");
			bw.write("8:" + sd.getL7ave() + "\t");
			bw.write("9:" + sd.getL7t() + "\t");
			bw.newLine();
		}
		bw.flush();
		System.out.println("Completed!");
	}
	
	public void reSetTrain(SvmData svmData, int j) {
		double[] data = new double[7];
		data[0] = svmData.getLt();
		data[1] = svmData.getL1t_1();
		data[2] = svmData.getL1t();
		data[3] = svmData.getL1t1();
		data[4] = svmData.getL1ave();
		data[5] = svmData.getL7t();
		data[6] = svmData.getL7ave();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		double[] maxmin = new double[8];
		
		String sql = "SELECT MAX(average),MIN(average),MAX(EC_ENERGY_" + (j-1) + "),MIN(EC_ENERGY_" + (j-1) + "),MAX(EC_ENERGY_" + j + "),MIN(EC_ENERGY_" + j + "),MAX(EC_ENERGY_" + (j+1) + "),MIN(EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_chuanjiang";

		try{
			connection = JdbcUtils.getConnection();
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				maxmin[0] = resultSet.getDouble(1);
				maxmin[1] = resultSet.getDouble(2);
				maxmin[2] = resultSet.getDouble(3);
				maxmin[3]= resultSet.getDouble(4);
				maxmin[4] = resultSet.getDouble(5);
				maxmin[5] = resultSet.getDouble(6);
				maxmin[6] = resultSet.getDouble(7);
				maxmin[7] = resultSet.getDouble(8);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		getAve(data, maxmin);
		svmData.setLt(data[0]);
		svmData.setL1t_1(data[1]);
		svmData.setL1t(data[2]);
		svmData.setL1t1(data[3]);
		svmData.setL1ave(data[4]);
		svmData.setL7t(data[5]);
		svmData.setL7ave(data[6]);
	}
	
	public void getAve(double[] data, double[] maxmin){
		data[0] =(data[0] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[2] =(data[2] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[5] =(data[5] - maxmin[5])/(maxmin[4] - maxmin[5]);
		data[1] =(data[1] - maxmin[3])/(maxmin[2] - maxmin[3]);
		data[3] =(data[3] - maxmin[7])/(maxmin[6] - maxmin[7]);
		data[4] =(data[4] - maxmin[1])/(maxmin[0] - maxmin[1]);
		data[6] =(data[6] - maxmin[1])/(maxmin[0] - maxmin[1]);
	}
	
	@SuppressWarnings("resource")
	public void getSql(LocalDate date, int j, SvmData svmData) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		String sql = null;
		String sql1 = null;
		String sql12 = null;
		String sql7 = null;
		sql = "SELECT DayType,EC_ENERGY_" + j + " FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		sql7 = "SELECT DayType,average,EC_ENERGY_" + j + " FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date.minusWeeks(1) + "', '%Y-%m-%d')";
		
		if(j != 1 && j != 24){
			sql1 = "SELECT DayType,average,EC_ENERGY_" + (j-1) +",EC_ENERGY_" + j + ",EC_ENERGY_" + (j+1) + " FROM ec_d_power_curve_average24_chuanjiang"
			+ " WHERE DATA_DATE = STR_TO_DATE('" + date.minusDays(1) + "', '%Y-%m-%d')";
		}else if(j == 1) {
			sql1 = "SELECT DayType,average,EC_ENERGY_" + j + ",EC_ENERGY_" + (j+1) + " FROM ec_d_power_curve_average24_chuanjiang"
			+ " WHERE DATA_DATE = STR_TO_DATE('" + date.minusDays(1) + "', '%Y-%m-%d')";
			sql12 = "SELECT EC_ENERGY_24 FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date.minusDays(2) + "', '%Y-%m-%d')";
		}else if (j == 24){
			sql1 = "SELECT DayType,average,EC_ENERGY_" + (j-1) +",EC_ENERGY_" + j + " FROM ec_d_power_curve_average24_chuanjiang"
					+ " WHERE DATA_DATE = STR_TO_DATE('" + date.minusDays(1) + "', '%Y-%m-%d')";
			sql12 = "SELECT EC_ENERGY_1 FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		}
		try {
			connection = JdbcUtils.getConnection();
			
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				svmData.setD(resultSet.getBoolean(1));
				svmData.setLt(resultSet.getDouble(2));
			}
			
			if(j != 1 && j != 24){
				statement = connection.prepareStatement(sql1);
				resultSet = statement.executeQuery();
				while(resultSet.next()){
					svmData.setD1(resultSet.getBoolean(1));
					svmData.setL1ave(resultSet.getDouble(2));
					svmData.setL1t_1(resultSet.getDouble(3));
					svmData.setL1t(resultSet.getDouble(4));
					svmData.setL1t1(resultSet.getDouble(5));
				}
			}else if(j == 1) {
				statement = connection.prepareStatement(sql1);
				resultSet = statement.executeQuery();
				while(resultSet.next()){
					svmData.setD1(resultSet.getBoolean(1));
					svmData.setL1ave(resultSet.getDouble(2));
					svmData.setL1t(resultSet.getDouble(3));
					svmData.setL1t1(resultSet.getDouble(4));
				}
				statement = connection.prepareStatement(sql12);
				resultSet = statement.executeQuery();
				while(resultSet.next()){
					svmData.setL1t_1(resultSet.getDouble(1));
				}
			}else {
				statement = connection.prepareStatement(sql1);
				resultSet = statement.executeQuery();
				while(resultSet.next()){
					svmData.setD1(resultSet.getBoolean(1));
					svmData.setL1ave(resultSet.getDouble(2));
					svmData.setL1t_1(resultSet.getDouble(3));
					svmData.setL1t(resultSet.getDouble(4));
				}
				statement = connection.prepareStatement(sql12);
				resultSet = statement.executeQuery();
				while(resultSet.next()){
					svmData.setL1t1(resultSet.getDouble(1));
				}
			}
			
			
			statement = connection.prepareStatement(sql7);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				svmData.setD7(resultSet.getBoolean(1));
				svmData.setL7ave(resultSet.getDouble(2));
				svmData.setL7t(resultSet.getDouble(3));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.releaseConnection(connection, statement, resultSet);
		}

	}
	
	public String getSql1(LocalDate date, int j) {
		date = date.minusDays(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + (j-1) +",EC_ENERGY_" + j + ",EC_ENERGY_" + (j+1) + ") FROM ec_d_power_curve_average24_chuanjiang"
				+ " WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
	public String getSql7(LocalDate date, int j) {
		date = date.minusWeeks(1);
		String sql = "SELECT (DayType,average,EC_ENERGY_" + j + ") FROM ec_d_power_curve_average24_chuanjiang WHERE DATA_DATE = STR_TO_DATE('" + date + "', '%Y-%m-%d')";
		return sql;
	}
	
	@Test
	public void go(){
		double[] result = write(0);
		for(int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
		}
	}
	
}
