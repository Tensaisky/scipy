package com.usst.edu.youhua;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

/*
 * ElecPrice �۵�͹�����
 * 
 * @author liangkehsun 
 */
public class ElecPrice
{
	/*
	 * ����DATE_TIME�õ�������
	 */
	public double[] buyPrice(LocalDate Day)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();// ���ù�������
			String sql = "SELECT * FROM mg_electricity_buyprice where DATE_TIME=? ;";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, "2017-01-01");// �����ȡ�̶�ֵ
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{// ������������
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

	/*
	 * ����version�õ�������
	 */
	public double[] buyPrice(double version)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "SELECT * FROM mg_electricity_buyprice where version=? ;";
			stmt = conn.prepareStatement(sql);
			stmt.setDouble(1, version);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

	/*
	 * ������Ϊ��ʱ������version�����ֵ�õ�������
	 */
	public double[] buyPrice()
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "select * from mg_electricity_buyprice where version=(select max(version) from mg_electricity_buyprice) ;";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

	/*
	 * ����LocalDate�õ��۵���
	 */
	public double[] salePrice(LocalDate Day)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "SELECT * FROM mg_electricity_saleprice where DATE_TIME=? ;";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, "2017-01-01");
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

	/*
	 * ����version�õ��۵���
	 */
	public double[] salePrice(double version)
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "SELECT * FROM mg_electricity_saleprice where version=? ;";
			stmt = conn.prepareStatement(sql);
			stmt.setDouble(1, version);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

	/*
	 * ������Ϊ��ʱ������version���ֵ�õ��۵���
	 */
	public double[] salePrice()
	{
		double[] arr = new double[96];
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			conn = MySQLConn.getConnection();
			String sql = "select * from mg_electricity_saleprice where version=(select max(version) from mg_electricity_saleprice) ;";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				for (int i = 0; i < 96; i++)
				{
					arr[i] = rs.getDouble("price_" + i);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			MySQLConn.close(rs, stmt, conn);
		}
		return arr;
	}

}
